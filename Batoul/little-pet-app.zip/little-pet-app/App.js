import React from 'react';
import { View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { AdoptionProvider } from './src/context/AdoptionContext';
import { HostingProvider } from './src/context/HostingContext';
import { ChatProvider } from './src/context/ChatContext';
import AdoptionBrowseScreen from './src/screens/adoption/AdoptionBrowseScreen';
import { COLORS } from './src/utils/constants';
import AdoptionDetailScreen from './src/screens/adoption/AdoptionDetailScreen';
import CreateAdoptionListingScreen from './src/screens/adoption/CreateAdoptionListingScreen';
import HostingBrowseScreen from './src/screens/hosting/HostingBrowseScreen';
import HostingDetailScreen from './src/screens/hosting/HostingDetailScreen';
import CreateHostingRequestScreen from './src/screens/hosting/CreateHostingRequestScreen';
import ChatScreen from './src/screens/chat/ChatScreen';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// Bottom Tab Navigator
function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: COLORS.primary,
        tabBarInactiveTintColor: COLORS.text.light,
        tabBarStyle: {
          height: 60,
          paddingBottom: 8,
          paddingTop: 8,
        },
        tabBarLabelStyle: {
          fontSize: 12,
        },
      }}
      initialRouteName="ServicesTab" 
    >
      <Tab.Screen 
        name="HomeTab" 
        component={AdoptionBrowseScreen}
        options={{
          tabBarLabel: 'الرئيسية',
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="home-outline" size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen 
  name="ServicesTab" 
  component={HostingBrowseScreen} // ← غيّر من AdoptionBrowseScreen
  options={{
    tabBarLabel: 'خدمات',
    tabBarIcon: ({ color, size }) => (
      <Ionicons name="grid-outline" size={size} color={color} />
    ),
  }}
/>
      <Tab.Screen 
  name="AddTab" 
  component={AdoptionBrowseScreen}
  options={{
    tabBarLabel: '',
    tabBarIcon: ({ focused }) => (
      <View style={{
        position: 'absolute',
        bottom: 20,
        width: 60,
        height: 60,
        borderRadius: 30,
        backgroundColor: COLORS.primary,
        justifyContent: 'center',
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 6,
        elevation: 8,
      }}>
        <Ionicons name="add" size={32} color={COLORS.white} />
      </View>
    ),
  }}
  listeners={({ navigation }) => ({
    tabPress: (e) => {
      e.preventDefault();
      navigation.navigate('CreateAdoptionListing'); 
    },
  })}
/>
      <Tab.Screen 
        name="CommunityTab" 
        component={AdoptionBrowseScreen}
        options={{
          tabBarLabel: 'مجتمع',
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="people-outline" size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen 
        name="ProfileTab" 
        component={AdoptionBrowseScreen}
        options={{
          tabBarLabel: 'حسابي',
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="person-outline" size={size} color={color} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <AdoptionProvider>
      <HostingProvider>
        <ChatProvider>
          <NavigationContainer>
            <Stack.Navigator
  screenOptions={{
    headerShown: false,
    presentation: 'card',
  }}
>
  <Stack.Screen 
    name="Main" 
    component={MainTabs}
    options={{
      animationEnabled: false,
    }}
  />
  <Stack.Screen 
    name="AdoptionDetail" 
    component={AdoptionDetailScreen}
  />
  <Stack.Screen 
    name="CreateAdoptionListing" 
    component={CreateAdoptionListingScreen}
  />
  <Stack.Screen 
    name="HostingBrowse" 
    component={HostingBrowseScreen}
  />
  <Stack.Screen 
    name="HostingDetail" 
    component={HostingDetailScreen}
  />
  <Stack.Screen 
    name="CreateHostingRequest" 
    component={CreateHostingRequestScreen}
  />
  <Stack.Screen 
    name="Chat" 
    component={ChatScreen}
  />
</Stack.Navigator>
          </NavigationContainer>
        </ChatProvider>
      </HostingProvider>
    </AdoptionProvider>
  );
}