/**
 * HostingCard - بطاقة عرض طلب الاستضافة
 * 
 * @param {Object} request - بيانات طلب الاستضافة
 * @param {Function} onPress - دالة عند الضغط على البطاقة
 */

import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, SPACING, FONT_SIZES, BORDER_RADIUS } from '../../src/utils/constants';

const HostingCard = ({ request, onPress }) => {
  // حساب عدد الأيام
  const startDate = new Date(request.startDate);
  const endDate = new Date(request.endDate);
  const days = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24));

  // تنسيق التواريخ
  const formatDate = (date) => {
    const d = new Date(date);
    return `${d.getDate()}/${d.getMonth() + 1}`;
  };

  return (
    <TouchableOpacity style={styles.card} onPress={onPress}>
      <View style={styles.imageContainer}>
        <Image 
          source={{ uri: request.photo || 'https://via.placeholder.com/150' }} 
          style={styles.image}
        />
        <View style={styles.badge}>
          <Text style={styles.badgeText}>{request.petType}</Text>
        </View>
      </View>
      
      <View style={styles.info}>
        <View style={styles.ownerRow}>
          <View style={styles.ownerAvatar}>
            <Ionicons name="person" size={16} color={COLORS.white} />
          </View>
          <Text style={styles.ownerName}>{request.owner.name}</Text>
        </View>

        <View style={styles.datesRow}>
          <Text style={styles.dates}>
            {formatDate(request.startDate)} - {formatDate(request.endDate)}
          </Text>
          <Text style={styles.duration}>• {days} {days === 1 ? 'يوم' : 'أيام'}</Text>
        </View>

        <View style={styles.locationRow}>
          <Ionicons name="location-outline" size={14} color={COLORS.text.light} />
          <Text style={styles.city}>{request.city}</Text>
        </View>

        <Text style={styles.requirements} numberOfLines={2}>
          {request.requirements}
        </Text>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
  width: '100%',
  backgroundColor: COLORS.white,
  borderRadius: BORDER_RADIUS.lg,
  marginBottom: SPACING.lg,
  overflow: 'hidden',
  ...Platform.select({
    ios: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
    },
    android: {
      elevation: 3,
    },
  }),
},
  imageContainer: {
    position: 'relative',
  },
  image: {
    width: '100%',
    height: 180,
    backgroundColor: COLORS.background,
  },
  badge: {
    position: 'absolute',
    top: SPACING.sm,
    right: SPACING.sm,
    backgroundColor: COLORS.primary,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.xs,
    borderRadius: BORDER_RADIUS.md,
  },
  badgeText: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.white,
    fontWeight: 'bold',
  },
  info: {
    padding: SPACING.md,
    alignItems: 'flex-end',
  },
  ownerRow: {
    flexDirection: 'row-reverse', // ← غيّر من row لـ row-reverse
    alignItems: 'center',
    marginBottom: SPACING.sm,
    alignSelf: 'flex-end',
  },
  ownerAvatar: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: SPACING.xs, // ← غيّر من marginLeft لـ marginRight
  },
  ownerName: {
    fontSize: FONT_SIZES.md,
    fontWeight: 'bold',
    color: COLORS.text.primary,
  },
  datesRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: SPACING.xs,
    alignSelf: 'flex-end',
  },
  dates: {
    fontSize: FONT_SIZES.md,
    fontWeight: 'bold',
    color: COLORS.text.primary,
  },
  duration: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.text.secondary,
    marginRight: SPACING.xs,
  },
  locationRow: {
    flexDirection: 'row-reverse', // ← غيّر من row لـ row-reverse
    alignItems: 'center',
    marginBottom: SPACING.sm,
    alignSelf: 'flex-end',
  },
  city: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.text.light,
    marginRight: SPACING.xs,
  },
  requirements: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.text.secondary,
    lineHeight: 20,
    textAlign: 'right',
  },
});

export default HostingCard;