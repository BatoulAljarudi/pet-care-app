import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, SPACING, FONT_SIZES } from '../../src/utils/constants';

const CustomHeader = ({ 
  title, 
  showBack = false, 
  onBackPress,
  showNotification = false,
  onNotificationPress,
  showSearch = false,
  onSearchPress,
  rightIcon,
  onRightIconPress,
}) => {
  return (
  <View style={styles.container}>
    <View style={styles.leftSection}>
      {showNotification && (
        <TouchableOpacity onPress={onNotificationPress} style={styles.iconButton}>
          <Ionicons name="notifications-outline" size={24} color={COLORS.text.primary} />
        </TouchableOpacity>
      )}
      {showSearch && (
        <TouchableOpacity onPress={onSearchPress} style={styles.iconButton}>
          <Ionicons name="search-outline" size={24} color={COLORS.text.primary} />
        </TouchableOpacity>
      )}
      {rightIcon && (
        <TouchableOpacity onPress={onRightIconPress} style={styles.iconButton}>
          <Ionicons name={rightIcon} size={24} color={COLORS.text.primary} />
        </TouchableOpacity>
      )}
    </View>

    <View style={styles.centerSection}>
      <Text style={styles.title}>{title}</Text>
    </View>

    <View style={styles.rightSection}>
      {showBack && (
        <TouchableOpacity onPress={onBackPress} style={styles.iconButton}>
          <Ionicons name="arrow-forward" size={24} color={COLORS.text.primary} />
        </TouchableOpacity>
      )}
    </View>
  </View>
);
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.md,
    backgroundColor: COLORS.white,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border.light,
    ...Platform.select({
      ios: {
        paddingTop: 50, // For iOS notch
      },
      android: {
        paddingTop: SPACING.md,
      },
    }),
  },
  leftSection: {
    flex: 1,
    alignItems: 'flex-start',
  },
  centerSection: {
    flex: 2,
    alignItems: 'center',
  },
  rightSection: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  title: {
    fontSize: FONT_SIZES.xl,
    fontWeight: 'bold',
    color: COLORS.text.primary,
  },
  iconButton: {
    padding: SPACING.sm,
    marginLeft: SPACING.sm,
  },
});

export default CustomHeader;