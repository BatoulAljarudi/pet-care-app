import React from 'react';
import { View, TextInput, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, SPACING, FONT_SIZES, BORDER_RADIUS } from '../../src/utils/constants';

const SearchBar = ({ 
  placeholder = 'ابحث...', 
  value, 
  onChangeText,
  showFilter = false,
  onFilterPress,
}) => {
  return (
    <View style={styles.container}>
      <View style={styles.searchContainer}>
        <Ionicons name="search-outline" size={20} color={COLORS.text.light} style={styles.searchIcon} />
        <TextInput
          style={styles.input}
          placeholder={placeholder}
          placeholderTextColor={COLORS.text.light}
          value={value}
          onChangeText={onChangeText}
        />
      </View>
      
      {showFilter && (
        <TouchableOpacity style={styles.filterButton} onPress={onFilterPress}>
          <Ionicons name="options-outline" size={24} color={COLORS.white} />
        </TouchableOpacity>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.sm, // كان SPACING.md ← غيّره لـ sm
    alignItems: 'center',
  },
  searchContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: SPACING.sm,
    backgroundColor: COLORS.white,
    borderRadius: BORDER_RADIUS.xl,
    paddingHorizontal: SPACING.md,
    height: 45, // ← أضف هذا السطر
  },
  searchIcon: {
    marginLeft: SPACING.sm,
  },
  input: {
    flex: 1,
    paddingVertical: SPACING.sm, // كان SPACING.md ← غيّره لـ sm
    paddingHorizontal: SPACING.sm,
    fontSize: FONT_SIZES.md,
    color: COLORS.text.primary,
    textAlign: 'right',
  },
  filterButton: {
    backgroundColor: COLORS.primary,
    padding: SPACING.sm, // كان SPACING.md ← غيّره لـ sm
    borderRadius: BORDER_RADIUS.xl,
    marginRight: SPACING.md,
    width: 45, // ← أضف هذا السطر
    height: 45, // ← أضف هذا السطر
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default SearchBar;