import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, SPACING, FONT_SIZES, BORDER_RADIUS } from '../../src/utils/constants';

const AdoptionFilters = ({ selectedType, onTypeChange }) => {
  const types = [
    { label: 'الكل', icon: 'apps' },
    { label: 'قطط', icon: 'paw' },
    { label: 'كلاب', icon: 'paw' },
    { label: 'طيور', icon: 'leaf' },
    { label: 'صقور', icon: 'leaf' },
    { label: 'أخرى', icon: 'ellipsis-horizontal' },
  ];

  return (
    <View style={styles.container}>
      <ScrollView 
  horizontal 
  showsHorizontalScrollIndicator={false} // ← هذا موجود بالفعل
  showsVerticalScrollIndicator={false}   // ← أضف هذا
  contentContainerStyle={styles.scrollContent}
>
        {types.map((type, index) => (
          <TouchableOpacity
            key={index}
            style={[
              styles.filterButton,
              selectedType === type.label && styles.filterButtonActive
            ]}
            onPress={() => onTypeChange(type.label)}
          >
            <Ionicons 
              name={type.icon} 
              size={18} 
              color={selectedType === type.label ? COLORS.white : COLORS.text.secondary}
              style={styles.icon}
            />
            <Text style={[
              styles.filterText,
              selectedType === type.label && styles.filterTextActive
            ]}>
              {type.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingVertical: SPACING.sm,
    backgroundColor: COLORS.background,
  },
  scrollContent: {
    paddingHorizontal: SPACING.lg,
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.sm,
    borderRadius: BORDER_RADIUS.xl,
    backgroundColor: COLORS.white,
    marginLeft: SPACING.sm,
    borderWidth: 1,
    borderColor: COLORS.border.light,
  },
  filterButtonActive: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  icon: {
    marginLeft: SPACING.xs,
  },
  filterText: {
    fontSize: FONT_SIZES.md,
    color: COLORS.text.secondary,
    fontWeight: '500',
  },
  filterTextActive: {
    color: COLORS.white,
    fontWeight: 'bold',
  },
});

export default AdoptionFilters;