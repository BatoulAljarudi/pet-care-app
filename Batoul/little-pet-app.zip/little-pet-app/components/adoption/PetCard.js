/**
 * PetCard - بطاقة عرض الحيوان في قائمة التبني
 * 
 * @param {Object} pet - بيانات الحيوان
 * @param {Function} onPress - دالة عند الضغط على البطاقة
 * @param {Function} onLikePress - دالة عند الضغط على القلب
 * @param {boolean} isLiked - هل الحيوان في المفضلة
 */

import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import {
  COLORS,
  SPACING,
  FONT_SIZES,
  BORDER_RADIUS,
} from '../../src/utils/constants';

const PetCard = ({ pet, onPress, onLikePress, isLiked = false }) => {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress}>
      <View style={styles.imageContainer}>
        <Image
          source={{ uri: pet.photos?.[0] || 'https://via.placeholder.com/150' }}
          style={styles.image}
        />
        <TouchableOpacity
          style={styles.likeButton}
          onPress={(e) => {
            e.stopPropagation();
            onLikePress && onLikePress();
          }}>
          <Ionicons
            name={isLiked ? 'heart' : 'heart-outline'}
            size={22}
            color={isLiked ? COLORS.status.error : COLORS.white}
          />
        </TouchableOpacity>
      </View>

      <View style={styles.info}>
        <Text style={styles.name} numberOfLines={1}>
          {pet.name}
        </Text>
        <Text style={styles.details} numberOfLines={1}>
          {pet.breed} • {pet.age}
        </Text>
        <View style={styles.locationRow}>
          <Ionicons
            name="location-outline"
            size={14}
            color={COLORS.text.light}
          />
          <Text style={styles.city}>{pet.city}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
  width: '48%',
  backgroundColor: COLORS.white,
  borderRadius: BORDER_RADIUS.lg,
  marginBottom: SPACING.lg,
  ...Platform.select({
    ios: {
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.1,
      shadowRadius: 4,
    },
    android: {
      elevation: 3,
    },
  }),
},
  imageContainer: {
    position: 'relative',
  },
  image: {
    width: '100%',
    height: 150,
    borderTopLeftRadius: BORDER_RADIUS.lg,
    borderTopRightRadius: BORDER_RADIUS.lg,
    backgroundColor: COLORS.background,
  },
  likeButton: {
    position: 'absolute',
    top: SPACING.sm,
    right: SPACING.sm,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    borderRadius: BORDER_RADIUS.round,
    padding: SPACING.sm,
  },
  info: {
    padding: SPACING.md,
  },
  name: {
    fontSize: FONT_SIZES.lg,
    fontWeight: 'bold',
    color: COLORS.text.primary,
    marginBottom: SPACING.xs,
  },
  details: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.text.secondary,
    marginBottom: SPACING.xs,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  city: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.text.light,
    marginRight: SPACING.xs,
  },
});

export default PetCard;
