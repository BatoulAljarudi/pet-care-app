/**
 * ChatContext - إدارة حالة المحادثات والرسائل
 * 
 * المسؤوليات:
 * - تحميل وحفظ المحادثات في AsyncStorage
 * - إنشاء محادثات جديدة
 * - إرسال الرسائل (نصية وصور)
 * - CRUD operations للمحادثات (Create, Read, Update, Delete)
 */

import React, { createContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const ChatContext = createContext();

export const ChatProvider = ({ children }) => {
  const [conversations, setConversations] = useState([]);
  const [loading, setLoading] = useState(true);

  // تحميل البيانات عند بدء التطبيق
  useEffect(() => {
    loadConversations();
  }, []);

  /**
   * تحميل المحادثات من AsyncStorage
   */
  const loadConversations = async () => {
    try {
      const stored = await AsyncStorage.getItem('conversations');
      if (stored) {
        setConversations(JSON.parse(stored));
      }
    } catch (error) {
      console.error('Error loading conversations:', error);
    } finally {
      setLoading(false);
    }
  };

  /**
   * حفظ المحادثات في AsyncStorage
   * @param {Array} convs - قائمة المحادثات المراد حفظها
   */
  const saveToStorage = async (convs) => {
    try {
      await AsyncStorage.setItem('conversations', JSON.stringify(convs));
    } catch (error) {
      console.error('Error saving conversations:', error);
    }
  };

  /**
   * الحصول على محادثة موجودة أو إنشاء محادثة جديدة (CREATE/READ)
   * @param {string} listingId - معرف الإعلان/الطلب
   * @param {string} listingType - نوع الإعلان (adoption أو hosting)
   * @param {string} otherUserName - اسم المستخدم الآخر
   * @returns {Object} المحادثة
   */
  const getOrCreateConversation = async (listingId, listingType, otherUserName) => {
    // البحث عن محادثة موجودة
    let conversation = conversations.find(
      conv => conv.listingId === listingId && conv.listingType === listingType
    );

    if (!conversation) {
      // إنشاء محادثة جديدة
      conversation = {
        id: Date.now().toString(),
        listingId,
        listingType,
        participants: ['current_user', 'other_user'],
        otherUserName,
        messages: [],
        createdAt: new Date().toISOString(),
      };

      const updated = [...conversations, conversation];
      setConversations(updated);
      await saveToStorage(updated);
    }

    return conversation;
  };

  /**
   * إرسال رسالة في محادثة (UPDATE)
   * @param {string} conversationId - معرف المحادثة
   * @param {Object} message - الرسالة (text أو imageUri)
   */
  const sendMessage = async (conversationId, message) => {
    const newMessage = {
      id: Date.now().toString(),
      ...message,
      timestamp: new Date().toISOString(),
    };

    const updated = conversations.map(conv => {
      if (conv.id === conversationId) {
        return {
          ...conv,
          messages: [...conv.messages, newMessage],
        };
      }
      return conv;
    });

    setConversations(updated);
    await saveToStorage(updated);
  };

  /**
   * الحصول على محادثة بواسطة ID (READ)
   * @param {string} id - معرف المحادثة
   * @returns {Object|undefined} المحادثة أو undefined
   */
  const getConversationById = (id) => {
    return conversations.find(conv => conv.id === id);
  };

  /**
   * الحصول على جميع محادثات المستخدم الحالي (READ)
   * @param {string} userId - معرف المستخدم
   * @returns {Array} قائمة المحادثات
   */
  const getUserConversations = (userId) => {
    return conversations.filter(conv => conv.participants.includes(userId));
  };

  /**
   * حذف محادثة (DELETE)
   * @param {string} conversationId - معرف المحادثة المراد حذفها
   */
  const deleteConversation = async (conversationId) => {
    const updated = conversations.filter(conv => conv.id !== conversationId);
    setConversations(updated);
    await saveToStorage(updated);
  };

  // القيم والدوال المتاحة للمكونات الأخرى
  const value = {
    conversations,
    loading,
    getOrCreateConversation,
    sendMessage,
    getConversationById,
    getUserConversations,
    deleteConversation,
  };

  return (
    <ChatContext.Provider value={value}>
      {children}
    </ChatContext.Provider>
  );
};