/**
 * AdoptionContext - إدارة حالة إعلانات التبني
 * 
 * المسؤوليات:
 * - تحميل وحفظ إعلانات التبني في AsyncStorage
 * - إدارة قائمة المفضلة
 * - CRUD operations للإعلانات (Create, Read, Update, Delete)
 */

import React, { createContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { dummyAdoptionListings } from '../utils/dummyData';

export const AdoptionContext = createContext();

export const AdoptionProvider = ({ children }) => {
  const [adoptionListings, setAdoptionListings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [favorites, setFavorites] = useState([]);

  // تحميل البيانات عند بدء التطبيق
  useEffect(() => {
    loadAdoptionListings();
    loadFavorites();
  }, []);

  /**
   * تحميل إعلانات التبني من AsyncStorage
   * إذا لم توجد بيانات، يتم تحميل البيانات التجريبية
   */
  const loadAdoptionListings = async () => {
  try {
    // ← احذف البيانات القديمة مؤقتاً
    await AsyncStorage.removeItem('adoptionListings');
    
    const stored = await AsyncStorage.getItem('adoptionListings');
    if (stored) {
      setAdoptionListings(JSON.parse(stored));
    } else {
      // تحميل البيانات التجريبية الجديدة
      setAdoptionListings(dummyAdoptionListings);
      await AsyncStorage.setItem('adoptionListings', JSON.stringify(dummyAdoptionListings));
    }
  } catch (error) {
    console.error('Error loading adoption listings:', error);
    setAdoptionListings(dummyAdoptionListings);
  } finally {
    setLoading(false);
  }
};

  /**
   * تحميل قائمة المفضلة من AsyncStorage
   */
  const loadFavorites = async () => {
    try {
      const stored = await AsyncStorage.getItem('favorites');
      if (stored) {
        setFavorites(JSON.parse(stored));
      }
    } catch (error) {
      console.error('Error loading favorites:', error);
    }
  };

  /**
   * حفظ الإعلانات في AsyncStorage
   * @param {Array} listings - قائمة الإعلانات المراد حفظها
   */
  const saveToStorage = async (listings) => {
    try {
      await AsyncStorage.setItem('adoptionListings', JSON.stringify(listings));
    } catch (error) {
      console.error('Error saving adoption listings:', error);
    }
  };

  /**
   * إضافة إعلان جديد (CREATE)
   * @param {Object} listing - بيانات الإعلان الجديد
   * @returns {Object} الإعلان المضاف مع ID وبيانات إضافية
   */
  const addListing = async (listing) => {
    const newListing = {
      id: Date.now().toString(),
      ...listing,
      status: 'active',
      createdAt: new Date().toISOString(),
      selectedUserId: null,
    };
    const updated = [...adoptionListings, newListing];
    setAdoptionListings(updated);
    await saveToStorage(updated);
    return newListing;
  };

  /**
   * تحديث حالة الإعلان (UPDATE)
   * @param {string} listingId - معرف الإعلان
   * @param {string} status - الحالة الجديدة (active أو closed)
   * @param {string} selectedUserId - معرف المستخدم المختار (اختياري)
   */
  const updateListingStatus = async (listingId, status, selectedUserId = null) => {
    const updated = adoptionListings.map(listing =>
      listing.id === listingId
        ? { ...listing, status, selectedUserId }
        : listing
    );
    setAdoptionListings(updated);
    await saveToStorage(updated);
  };

  /**
   * الحصول على إعلان بواسطة ID (READ)
   * @param {string} id - معرف الإعلان
   * @returns {Object|undefined} الإعلان المطلوب أو undefined إذا لم يوجد
   */
  const getListingById = (id) => {
    return adoptionListings.find(listing => listing.id === id);
  };

  /**
   * إضافة أو إزالة إعلان من المفضلة
   * @param {string} listingId - معرف الإعلان
   */
  const toggleFavorite = async (listingId) => {
    const isFavorite = favorites.includes(listingId);
    let updated;
    
    if (isFavorite) {
      // إزالة من المفضلة
      updated = favorites.filter(id => id !== listingId);
    } else {
      // إضافة للمفضلة
      updated = [...favorites, listingId];
    }
    
    setFavorites(updated);
    await AsyncStorage.setItem('favorites', JSON.stringify(updated));
  };

  /**
   * حذف إعلان (DELETE)
   * @param {string} listingId - معرف الإعلان المراد حذفه
   */
  const deleteListing = async (listingId) => {
    const updated = adoptionListings.filter(listing => listing.id !== listingId);
    setAdoptionListings(updated);
    await saveToStorage(updated);
    
    // حذف من المفضلة أيضاً إذا كان موجوداً
    const updatedFavorites = favorites.filter(id => id !== listingId);
    setFavorites(updatedFavorites);
    await AsyncStorage.setItem('favorites', JSON.stringify(updatedFavorites));
  };

  // القيم والدوال المتاحة للمكونات الأخرى
  const value = {
    adoptionListings,
    loading,
    favorites,
    addListing,
    updateListingStatus,
    getListingById,
    toggleFavorite,
    deleteListing,
    refreshListings: loadAdoptionListings,
  };

  return (
    <AdoptionContext.Provider value={value}>
      {children}
    </AdoptionContext.Provider>
  );
};