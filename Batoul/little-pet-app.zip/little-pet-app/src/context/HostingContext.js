/**
 * HostingContext - إدارة حالة طلبات الاستضافة
 * 
 * المسؤوليات:
 * - تحميل وحفظ طلبات الاستضافة في AsyncStorage
 * - CRUD operations للطلبات (Create, Read, Update, Delete)
 */

import React, { createContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { dummyHostingRequests } from '../utils/dummyData';

export const HostingContext = createContext();

export const HostingProvider = ({ children }) => {
  const [hostingRequests, setHostingRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  // تحميل البيانات عند بدء التطبيق
  useEffect(() => {
    loadHostingRequests();
  }, []);

  /**
   * تحميل طلبات الاستضافة من AsyncStorage
   * إذا لم توجد بيانات، يتم تحميل البيانات التجريبية
   */
  const loadHostingRequests = async () => {
  try {
    // ← احذف البيانات القديمة مؤقتاً
    await AsyncStorage.removeItem('hostingRequests');
    
    const stored = await AsyncStorage.getItem('hostingRequests');
    if (stored) {
      setHostingRequests(JSON.parse(stored));
    } else {
      // تحميل البيانات التجريبية الجديدة
      setHostingRequests(dummyHostingRequests);
      await AsyncStorage.setItem('hostingRequests', JSON.stringify(dummyHostingRequests));
    }
  } catch (error) {
    console.error('Error loading hosting requests:', error);
    setHostingRequests(dummyHostingRequests);
  } finally {
    setLoading(false);
  }
};

  /**
   * حفظ الطلبات في AsyncStorage
   * @param {Array} requests - قائمة الطلبات المراد حفظها
   */
  const saveToStorage = async (requests) => {
    try {
      await AsyncStorage.setItem('hostingRequests', JSON.stringify(requests));
    } catch (error) {
      console.error('Error saving hosting requests:', error);
    }
  };

  /**
   * إضافة طلب استضافة جديد (CREATE)
   * @param {Object} request - بيانات الطلب الجديد
   * @returns {Object} الطلب المضاف مع ID وبيانات إضافية
   */
  const addRequest = async (request) => {
    const newRequest = {
      id: Date.now().toString(),
      ...request,
      status: 'active',
      createdAt: new Date().toISOString(),
      selectedUserId: null,
    };
    const updated = [...hostingRequests, newRequest];
    setHostingRequests(updated);
    await saveToStorage(updated);
    return newRequest;
  };

  /**
   * تحديث حالة الطلب (UPDATE)
   * @param {string} requestId - معرف الطلب
   * @param {string} status - الحالة الجديدة (active أو closed)
   * @param {string} selectedUserId - معرف المستخدم المختار (اختياري)
   */
  const updateRequestStatus = async (requestId, status, selectedUserId = null) => {
    const updated = hostingRequests.map(request =>
      request.id === requestId
        ? { ...request, status, selectedUserId }
        : request
    );
    setHostingRequests(updated);
    await saveToStorage(updated);
  };

  /**
   * الحصول على طلب بواسطة ID (READ)
   * @param {string} id - معرف الطلب
   * @returns {Object|undefined} الطلب المطلوب أو undefined إذا لم يوجد
   */
  const getRequestById = (id) => {
    return hostingRequests.find(request => request.id === id);
  };

  /**
   * حذف طلب استضافة (DELETE)
   * @param {string} requestId - معرف الطلب المراد حذفه
   */
  const deleteRequest = async (requestId) => {
    const updated = hostingRequests.filter(request => request.id !== requestId);
    setHostingRequests(updated);
    await saveToStorage(updated);
  };

  // القيم والدوال المتاحة للمكونات الأخرى
  const value = {
    hostingRequests,
    loading,
    addRequest,
    updateRequestStatus,
    getRequestById,
    deleteRequest,
    refreshRequests: loadHostingRequests,
  };

  return (
    <HostingContext.Provider value={value}>
      {children}
    </HostingContext.Provider>
  );
};