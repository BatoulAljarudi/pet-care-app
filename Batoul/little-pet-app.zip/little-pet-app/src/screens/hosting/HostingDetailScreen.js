import React, { useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { HostingContext } from '../../context/HostingContext';
import CustomHeader from '../../../components/common/CustomHeader';
import { COLORS, SPACING, FONT_SIZES, BORDER_RADIUS } from '../../utils/constants';

const HostingDetailScreen = ({ route, navigation }) => {
  const { requestId } = route.params;
  const { getRequestById, deleteRequest } = useContext(HostingContext);
  const request = getRequestById(requestId);

  if (!request) {
    return (
      <View style={styles.centerContainer}>
        <Text>الطلب غير موجود</Text>
      </View>
    );
  }

  // التحقق إذا كان الطلب خاصاً بي
const isMyRequest = request.owner.userId === 'current_user';

  const handleContact = () => {
  navigation.navigate('Chat', {
    listingId: request.id,
    listingType: 'hosting',
    otherUserName: request.owner.name,
  });
};

  // حساب عدد الأيام
  const startDate = new Date(request.startDate);
  const endDate = new Date(request.endDate);
  const days = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24));

  // تنسيق التواريخ
  const formatDate = (date) => {
    const d = new Date(date);
    const months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
    return `${d.getDate()} ${months[d.getMonth()]}`;
  };

  return (
    <View style={styles.container}>
      <CustomHeader
        title=""
        showBack={true}
        onBackPress={() => navigation.goBack()}
      />

      <View style={styles.content}>
        {/* Photo */}
        <Image
          source={{ uri: request.photo }}
          style={styles.photo}
        />

        <View style={styles.badge}>
          <Text style={styles.badgeText}>{request.petType}</Text>
        </View>

        {/* Info Card */}
        <View style={styles.infoCard}>
          <View style={styles.dateSection}>
            <View style={styles.dateBox}>
              <Ionicons name="calendar-outline" size={24} color={COLORS.primary} />
              <Text style={styles.dateLabel}>إلى</Text>
              <Text style={styles.dateValue}>{formatDate(request.endDate)}</Text>
            </View>

            <View style={styles.durationBox}>
              <Ionicons name="time-outline" size={20} color={COLORS.text.secondary} />
              <Text style={styles.durationText}>{days} {days === 1 ? 'يوم' : 'أيام'}</Text>
            </View>

            <View style={styles.dateBox}>
              <Ionicons name="calendar-outline" size={24} color={COLORS.primary} />
              <Text style={styles.dateLabel}>من</Text>
              <Text style={styles.dateValue}>{formatDate(request.startDate)}</Text>
            </View>
          </View>

          <View style={styles.locationRow}>
            <Ionicons name="location" size={20} color={COLORS.primary} />
            <Text style={styles.cityText}>{request.city}</Text>
          </View>
        </View>

        {/* Requirements */}
        <View style={styles.sectionCard}>
          <Text style={styles.sectionTitle}>التفاصيل والمتطلبات</Text>
          <Text style={styles.sectionText}>{request.requirements}</Text>
        </View>

        {/* Owner Info */}
        <View style={styles.ownerCard}>
          <Text style={styles.sectionTitle}>صاحب الطلب</Text>
          <View style={styles.ownerRow}>
            <View style={styles.ownerAvatar}>
              <Ionicons name="person" size={24} color={COLORS.white} />
            </View>
            <View style={styles.ownerInfo}>
              <Text style={styles.ownerName}>{request.owner.name}</Text>
              <Text style={styles.ownerMeta}>
                {request.owner.city} • عضو منذ {request.owner.memberSince}
              </Text>
            </View>
          </View>
        </View>
      </View>

      {/* Contact Button */}
      {/* Contact/Delete Button */}
<View style={styles.footer}>
  {isMyRequest ? (
    <TouchableOpacity
      style={styles.deleteButton}
      onPress={() => {
        Alert.alert(
          'حذف الطلب',
          'هل أنت متأكد من حذف هذا الطلب؟',
          [
            { text: 'إلغاء', style: 'cancel' },
            {
              text: 'حذف',
              style: 'destructive',
              onPress: async () => {
                await deleteRequest(request.id);
                Alert.alert('تم الحذف', 'تم حذف الطلب بنجاح');
                navigation.goBack();
              },
            },
          ]
        );
      }}
    >
      <Ionicons name="trash-outline" size={20} color={COLORS.white} />
      <Text style={styles.deleteButtonText}>حذف الطلب</Text>
    </TouchableOpacity>
  ) : (
    <TouchableOpacity
      style={styles.contactButton}
      onPress={handleContact}
    >
      <Ionicons name="chatbubble-outline" size={20} color={COLORS.white} />
      <Text style={styles.contactButtonText}>تواصل</Text>
    </TouchableOpacity>
  )}
</View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  photo: {
    width: '100%',
    height: 300,
    backgroundColor: COLORS.border.light,
  },
  badge: {
    position: 'absolute',
    top: SPACING.lg,
    right: SPACING.lg,
    backgroundColor: COLORS.primary,
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.sm,
    borderRadius: BORDER_RADIUS.md,
  },
  badgeText: {
    fontSize: FONT_SIZES.md,
    color: COLORS.white,
    fontWeight: 'bold',
  },
  infoCard: {
    backgroundColor: COLORS.white,
    margin: SPACING.lg,
    padding: SPACING.lg,
    borderRadius: BORDER_RADIUS.lg,
  },
  dateSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.lg,
  },
  dateBox: {
    alignItems: 'center',
    flex: 1,
  },
  dateLabel: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.text.secondary,
    marginTop: SPACING.xs,
  },
  dateValue: {
    fontSize: FONT_SIZES.md,
    fontWeight: 'bold',
    color: COLORS.text.primary,
    marginTop: SPACING.xs,
  },
  durationBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.background,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    borderRadius: BORDER_RADIUS.md,
  },
  durationText: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.text.secondary,
    marginRight: SPACING.xs,
    fontWeight: 'bold',
  },
  locationRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.background,
    paddingVertical: SPACING.sm,
    borderRadius: BORDER_RADIUS.md,
  },
  cityText: {
    fontSize: FONT_SIZES.md,
    color: COLORS.text.primary,
    fontWeight: 'bold',
    marginRight: SPACING.xs,
  },
  sectionCard: {
    backgroundColor: COLORS.white,
    marginHorizontal: SPACING.lg,
    marginBottom: SPACING.md,
    padding: SPACING.lg,
    borderRadius: BORDER_RADIUS.lg,
  },
  sectionTitle: {
    fontSize: FONT_SIZES.lg,
    fontWeight: 'bold',
    color: COLORS.text.primary,
    marginBottom: SPACING.md,
    textAlign: 'right',
  },
  sectionText: {
    fontSize: FONT_SIZES.md,
    color: COLORS.text.secondary,
    lineHeight: 24,
    textAlign: 'right',
  },
  ownerCard: {
    backgroundColor: COLORS.white,
    marginHorizontal: SPACING.lg,
    marginBottom: SPACING.md,
    padding: SPACING.lg,
    borderRadius: BORDER_RADIUS.lg,
  },
  ownerRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
  },
  ownerAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: SPACING.md,
  },
  ownerInfo: {
    flex: 1,
    alignItems: 'flex-end',
  },
  ownerName: {
    fontSize: FONT_SIZES.lg,
    fontWeight: 'bold',
    color: COLORS.text.primary,
  },
  ownerMeta: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.text.secondary,
    marginTop: SPACING.xs,
  },
  footer: {
    backgroundColor: COLORS.white,
    padding: SPACING.lg,
    borderTopWidth: 1,
    borderTopColor: COLORS.border.light,
  },
  contactButton: {
    backgroundColor: COLORS.primary,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: SPACING.md,
    borderRadius: BORDER_RADIUS.md,
  },
  contactButtonText: {
    fontSize: FONT_SIZES.lg,
    fontWeight: 'bold',
    color: COLORS.white,
    marginRight: SPACING.sm,
  },
  deleteButton: {
  backgroundColor: COLORS.status.error,
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'center',
  paddingVertical: SPACING.md,
  borderRadius: BORDER_RADIUS.md,
},
deleteButtonText: {
  fontSize: FONT_SIZES.lg,
  fontWeight: 'bold',
  color: COLORS.white,
  marginRight: SPACING.sm,
},
});

export default HostingDetailScreen;