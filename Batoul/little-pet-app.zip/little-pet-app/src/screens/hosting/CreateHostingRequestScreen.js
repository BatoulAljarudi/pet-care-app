import React, { useState, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  Alert,
  Platform,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Ionicons } from '@expo/vector-icons';
import { HostingContext } from '../../context/HostingContext';
import CustomHeader from '../../../components/common/CustomHeader';
import { COLORS, SPACING, FONT_SIZES, BORDER_RADIUS, PET_TYPES, CITIES } from '../../utils/constants';

const CreateHostingRequestScreen = ({ navigation }) => {
  const { addRequest } = useContext(HostingContext);
  
  const [photo, setPhoto] = useState(null);
  const [petType, setPetType] = useState('');
  const [city, setCity] = useState('');
  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)); // +7 days
  const [showStartDatePicker, setShowStartDatePicker] = useState(false);
  const [showEndDatePicker, setShowEndDatePicker] = useState(false);
  const [requirements, setRequirements] = useState('');

  const pickImage = async () => {
  // طلب الصلاحيات
  const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
  
  if (status !== 'granted') {
    Alert.alert(
      'صلاحية مطلوبة',
      'نحتاج إلى صلاحية الوصول للمعرض لإضافة الصور',
      [{ text: 'حسناً' }]
    );
    return;
  }

  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ImagePicker.MediaTypeOptions.Images,
    allowsEditing: true,
    aspect: [4, 3],
    quality: 0.8,
  });

  if (!result.canceled) {
    setPhoto(result.assets[0].uri);
  }
};

  const handleStartDateChange = (event, selectedDate) => {
    setShowStartDatePicker(false);
    if (selectedDate) {
      setStartDate(selectedDate);
      // تأكد أن تاريخ النهاية بعد تاريخ البداية
      if (selectedDate >= endDate) {
        setEndDate(new Date(selectedDate.getTime() + 24 * 60 * 60 * 1000));
      }
    }
  };

  const handleEndDateChange = (event, selectedDate) => {
    setShowEndDatePicker(false);
    if (selectedDate) {
      setEndDate(selectedDate);
    }
  };

  const formatDate = (date) => {
    return `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
  };

  const handleSubmit = async () => {
    // Validation
    if (!petType) {
      Alert.alert('خطأ', 'يرجى اختيار نوع الأليف');
      return;
    }
    if (!city) {
      Alert.alert('خطأ', 'يرجى اختيار المدينة');
      return;
    }
    if (!photo) {
      Alert.alert('خطأ', 'يرجى إضافة صورة');
      return;
    }
    if (!requirements.trim()) {
      Alert.alert('خطأ', 'يرجى كتابة التفاصيل والمتطلبات');
      return;
    }
    if (startDate >= endDate) {
      Alert.alert('خطأ', 'تاريخ النهاية يجب أن يكون بعد تاريخ البداية');
      return;
    }

    const newRequest = {
      petType,
      photo,
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
      city,
      requirements: requirements.trim(),
      owner: {
        name: 'المستخدم الحالي',
        city: city,
        memberSince: new Date().getFullYear().toString(),
        userId: 'current_user',
      },
    };

    await addRequest(newRequest);
    Alert.alert('نجح', 'تم إضافة الطلب بنجاح', [
      { text: 'حسناً', onPress: () => navigation.goBack() }
    ]);
  };

  return (
    <View style={styles.container}>
      <CustomHeader
        title="طلب استضافة"
        showBack={true}
        onBackPress={() => navigation.goBack()}
      />

      <View style={styles.content}>
        {/* Photo Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>صورة الأليف *</Text>
          {photo ? (
            <View style={styles.photoWrapper}>
              <Image source={{ uri: photo }} style={styles.photoPreview} />
              <TouchableOpacity
                style={styles.removePhotoButton}
                onPress={() => setPhoto(null)}
              >
                <Ionicons name="close-circle" size={32} color={COLORS.status.error} />
              </TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity style={styles.addPhotoButton} onPress={pickImage}>
              <Ionicons name="camera" size={48} color={COLORS.primary} />
              <Text style={styles.addPhotoText}>إضافة صورة</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Pet Type */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>نوع الأليف *</Text>
          <View style={styles.chipsContainer}>
            {PET_TYPES.filter(type => type !== 'الكل').map((type) => (
              <TouchableOpacity
                key={type}
                style={[
                  styles.chip,
                  petType === type && styles.chipActive,
                ]}
                onPress={() => setPetType(type)}
              >
                <Text style={[
                  styles.chipText,
                  petType === type && styles.chipTextActive,
                ]}>
                  {type}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Dates */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>الفترة المطلوبة *</Text>
          
          <View style={styles.dateRow}>
            <TouchableOpacity
              style={styles.dateButton}
              onPress={() => setShowStartDatePicker(true)}
            >
              <Ionicons name="calendar-outline" size={20} color={COLORS.primary} />
              <View style={styles.dateInfo}>
                <Text style={styles.dateLabel}>من</Text>
                <Text style={styles.dateValue}>{formatDate(startDate)}</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.dateButton}
              onPress={() => setShowEndDatePicker(true)}
            >
              <Ionicons name="calendar-outline" size={20} color={COLORS.primary} />
              <View style={styles.dateInfo}>
                <Text style={styles.dateLabel}>إلى</Text>
                <Text style={styles.dateValue}>{formatDate(endDate)}</Text>
              </View>
            </TouchableOpacity>
          </View>

          {showStartDatePicker && (
            <DateTimePicker
              value={startDate}
              mode="date"
              display="default"
              onChange={handleStartDateChange}
              minimumDate={new Date()}
            />
          )}

          {showEndDatePicker && (
            <DateTimePicker
              value={endDate}
              mode="date"
              display="default"
              onChange={handleEndDateChange}
              minimumDate={startDate}
            />
          )}
        </View>

        {/* City */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>المدينة *</Text>
          <View style={styles.chipsContainer}>
            {CITIES.filter(c => c !== 'الكل').map((c) => (
              <TouchableOpacity
                key={c}
                style={[
                  styles.chip,
                  city === c && styles.chipActive,
                ]}
                onPress={() => setCity(c)}
              >
                <Text style={[
                  styles.chipText,
                  city === c && styles.chipTextActive,
                ]}>
                  {c}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Requirements */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>التفاصيل والمتطلبات *</Text>
          <TextInput
            style={[styles.input, styles.textArea]}
            placeholder="اكتب تفاصيل الأليف والمتطلبات للمستضيف..."
            value={requirements}
            onChangeText={setRequirements}
            multiline
            numberOfLines={5}
          />
        </View>
      </View>

      {/* Submit Button */}
      <View style={styles.footer}>
        <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
          <Text style={styles.submitButtonText}>نشر الطلب</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  content: {
    flex: 1,
    padding: SPACING.lg,
  },
  section: {
    marginBottom: SPACING.xl,
  },
  sectionTitle: {
    fontSize: FONT_SIZES.lg,
    fontWeight: 'bold',
    color: COLORS.text.primary,
    marginBottom: SPACING.md,
    textAlign: 'right',
  },
  photoWrapper: {
    position: 'relative',
    alignSelf: 'center',
  },
  photoPreview: {
    width: 200,
    height: 200,
    borderRadius: BORDER_RADIUS.lg,
    backgroundColor: COLORS.border.light,
  },
  removePhotoButton: {
    position: 'absolute',
    top: -10,
    left: -10,
    backgroundColor: COLORS.white,
    borderRadius: 16,
  },
  addPhotoButton: {
    height: 200,
    borderRadius: BORDER_RADIUS.lg,
    borderWidth: 2,
    borderColor: COLORS.primary,
    borderStyle: 'dashed',
    justifyContent: 'center',
    alignItems: 'center',
  },
  addPhotoText: {
    fontSize: FONT_SIZES.md,
    color: COLORS.primary,
    marginTop: SPACING.sm,
  },
  chipsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'flex-end',
  },
  chip: {
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.sm,
    borderRadius: BORDER_RADIUS.xl,
    backgroundColor: COLORS.white,
    marginLeft: SPACING.sm,
    marginBottom: SPACING.sm,
    borderWidth: 1,
    borderColor: COLORS.border.light,
  },
  chipActive: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  chipText: {
    fontSize: FONT_SIZES.md,
    color: COLORS.text.secondary,
  },
  chipTextActive: {
    color: COLORS.white,
    fontWeight: 'bold',
  },
  dateRow: {
    flexDirection: 'row-reverse',
    justifyContent: 'space-between',
  },
  dateButton: {
    flex: 1,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: COLORS.white,
    padding: SPACING.md,
    borderRadius: BORDER_RADIUS.md,
    marginHorizontal: SPACING.xs,
  },
  dateInfo: {
    alignItems: 'flex-end',
    marginRight: SPACING.sm,
  },
  dateLabel: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.text.secondary,
  },
  dateValue: {
    fontSize: FONT_SIZES.md,
    fontWeight: 'bold',
    color: COLORS.text.primary,
    marginTop: SPACING.xs,
  },
  input: {
    backgroundColor: COLORS.white,
    borderRadius: BORDER_RADIUS.md,
    padding: SPACING.md,
    fontSize: FONT_SIZES.md,
    color: COLORS.text.primary,
    borderWidth: 1,
    borderColor: COLORS.border.light,
    textAlign: 'right',
  },
  textArea: {
    height: 120,
    textAlignVertical: 'top',
  },
  footer: {
    backgroundColor: COLORS.white,
    padding: SPACING.lg,
    borderTopWidth: 1,
    borderTopColor: COLORS.border.light,
  },
  submitButton: {
    backgroundColor: COLORS.primary,
    paddingVertical: SPACING.md,
    borderRadius: BORDER_RADIUS.md,
    alignItems: 'center',
  },
  submitButtonText: {
    fontSize: FONT_SIZES.lg,
    fontWeight: 'bold',
    color: COLORS.white,
  },
});

export default CreateHostingRequestScreen;