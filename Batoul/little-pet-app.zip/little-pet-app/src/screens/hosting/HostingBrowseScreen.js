import React, { useState, useContext, useRef } from 'react';
import {
  View,
  FlatList,
  StyleSheet,
  ActivityIndicator,
  RefreshControl,
  Animated,
} from 'react-native';
import { HostingContext } from '../../context/HostingContext';
import HostingCard from '../../../components/hosting/HostingCard';
import CustomHeader from '../../../components/common/CustomHeader';
import TabSwitch from '../../../components/common/TabSwitch';
import SearchBar from '../../../components/common/SearchBar';
import FilterModal from '../../../components/common/FilterModal';
import { COLORS, SPACING } from '../../utils/constants';

const HostingBrowseScreen = ({ navigation }) => {
  const { hostingRequests, loading, refreshRequests } = useContext(HostingContext);
  
  const [activeTab, setActiveTab] = useState('استضف أليف');
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [filters, setFilters] = useState({
    city: 'الكل',
    petType: 'الكل',
  });
  const [refreshing, setRefreshing] = useState(false);

  // Animation for hiding/showing filters
  const scrollY = useRef(new Animated.Value(0)).current;
  const filterHeight = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [0, -200],
    extrapolate: 'clamp',
  });


// Filter requests
const filteredRequests = hostingRequests.filter(request => {
  // Filter by Tab
  if (activeTab === 'أحتاج مستضيف') {
    // عرض طلباتي الشخصية فقط
    if (request.owner.userId !== 'current_user') {
      return false;
    }
  } else {
    // استضف أليف - عرض طلبات الآخرين فقط
    if (request.owner.userId === 'current_user') {
      return false;
    }
  }

  if (filters.city !== 'الكل' && request.city !== filters.city) {
    return false;
  }
  
  if (filters.petType !== 'الكل' && request.petType !== filters.petType) {
    return false;
  }
  
  if (searchQuery && !request.owner.name.toLowerCase().includes(searchQuery.toLowerCase())) {
    return false;
  }
  
  return true;
});

  const onRefresh = async () => {
    setRefreshing(true);
    await refreshRequests();
    setRefreshing(false);
  };

  const handleRequestPress = (requestId) => {
    navigation.navigate('HostingDetail', { requestId });
  };

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color={COLORS.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <CustomHeader
        title="استضافة أليف"
        showBack={true}
        onBackPress={() => navigation.goBack()}
        showNotification={true}
        onNotificationPress={() => {}}
      />
      
      <View style={styles.content}>
        <Animated.View 
          style={[
            styles.filtersContainer,
            { transform: [{ translateY: filterHeight }] }
          ]}
        >
          <TabSwitch
            tabs={['أحتاج مستضيف', 'استضف أليف']}
            activeTab={activeTab}
            onTabChange={setActiveTab}
          />
          
          <SearchBar
            placeholder="ابحث عن طلب..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            showFilter={true}
            onFilterPress={() => setShowFilterModal(true)}
          />
        </Animated.View>
        
        <FlatList
          data={filteredRequests}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          onScroll={Animated.event(
            [{ nativeEvent: { contentOffset: { y: scrollY } } }],
            { useNativeDriver: true }
          )}
          scrollEventThrottle={16}
          renderItem={({ item }) => (
            <HostingCard 
              request={item}
              onPress={() => handleRequestPress(item.id)}
            />
          )}
          refreshControl={
            <RefreshControl 
              refreshing={refreshing}
              onRefresh={onRefresh}
              colors={[COLORS.primary]}
            />
          }
        />
      </View>
      
      <FilterModal
        visible={showFilterModal}
        onClose={() => setShowFilterModal(false)}
        filters={filters}
        onApply={(newFilters) => {
          setFilters(newFilters);
          setShowFilterModal(false);
        }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.background,
  },
  content: {
    flex: 1,
    overflow: 'hidden',
  },
  filtersContainer: {
    backgroundColor: COLORS.background,
    zIndex: 10,
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
  },
  listContent: {
    padding: SPACING.lg,
    paddingBottom: 100,
    paddingTop: 150, // ارتفاع الفلاتر
  },
});

export default HostingBrowseScreen;