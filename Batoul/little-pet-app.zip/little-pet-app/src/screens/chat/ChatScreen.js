import React, { useState, useContext, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TextInput,
  TouchableOpacity,
  Image,
  KeyboardAvoidingView,
  Platform,
  Alert, 
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { ChatContext } from '../../context/ChatContext';
import { COLORS, SPACING, FONT_SIZES, BORDER_RADIUS } from '../../utils/constants';

const ChatScreen = ({ route, navigation }) => {
  const { listingId, listingType, otherUserName } = route.params;
  const { getOrCreateConversation, sendMessage } = useContext(ChatContext);
  
  const [conversation, setConversation] = useState(null);
  const [messageText, setMessageText] = useState('');
  const flatListRef = useRef(null);

  useEffect(() => {
    loadConversation();
  }, []);

  const loadConversation = async () => {
    const conv = await getOrCreateConversation(listingId, listingType, otherUserName);
    setConversation(conv);
  };

  const handleSend = async () => {
    if (!messageText.trim()) return;

    const message = {
      text: messageText.trim(),
      senderId: 'current_user',
    };

    await sendMessage(conversation.id, message);
    setMessageText('');
    
    // Reload conversation
    await loadConversation();
    
    // Scroll to bottom
    setTimeout(() => {
      flatListRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  const handleSendImage = async () => {
  // طلب الصلاحيات
  const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
  
  if (status !== 'granted') {
    Alert.alert(
      'صلاحية مطلوبة',
      'نحتاج إلى صلاحية الوصول للمعرض لإرسال الصور',
      [{ text: 'حسناً' }]
    );
    return;
  }

  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ImagePicker.MediaTypeOptions.Images,
    allowsEditing: true,
    quality: 0.8,
  });

  if (!result.canceled) {
    const message = {
      imageUri: result.assets[0].uri,
      senderId: 'current_user',
    };

    await sendMessage(conversation.id, message);
    await loadConversation();
    
    setTimeout(() => {
      flatListRef.current?.scrollToEnd({ animated: true });
    }, 100);
  }
};

  const renderMessage = ({ item, index }) => {
    const isMyMessage = item.senderId === 'current_user';
    const showDate = index === 0 || !isSameDay(
      new Date(item.timestamp),
      new Date(conversation.messages[index - 1].timestamp)
    );

    return (
      <View>
        {showDate && (
          <View style={styles.dateDivider}>
            <Text style={styles.dateText}>{formatDate(item.timestamp)}</Text>
          </View>
        )}
        
        <View style={[
          styles.messageContainer,
          isMyMessage ? styles.myMessageContainer : styles.otherMessageContainer,
        ]}>
          {!isMyMessage && (
            <View style={styles.otherAvatar}>
              <Ionicons name="person" size={16} color={COLORS.white} />
            </View>
          )}
          
          <View style={[
            styles.messageBubble,
            isMyMessage ? styles.myMessageBubble : styles.otherMessageBubble,
          ]}>
            {item.imageUri ? (
              <Image source={{ uri: item.imageUri }} style={styles.messageImage} />
            ) : (
              <Text style={[
                styles.messageText,
                isMyMessage ? styles.myMessageText : styles.otherMessageText,
              ]}>
                {item.text}
              </Text>
            )}
            
            <View style={styles.messageFooter}>
              <Text style={[
                styles.timeText,
                isMyMessage ? styles.myTimeText : styles.otherTimeText,
              ]}>
                {formatTime(item.timestamp)}
              </Text>
              {isMyMessage && (
                <Ionicons name="checkmark-done" size={16} color={COLORS.white} style={styles.checkmark} />
              )}
            </View>
          </View>
        </View>
      </View>
    );
  };

  const isSameDay = (date1, date2) => {
    return date1.toDateString() === date2.toDateString();
  };

  const formatDate = (timestamp) => {
    const date = new Date(timestamp);
    const today = new Date();
    
    if (isSameDay(date, today)) {
      return 'اليوم';
    }
    
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (isSameDay(date, yesterday)) {
      return 'أمس';
    }
    
    return `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
  };

  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const ampm = hours >= 12 ? 'م' : 'ص';
    const hour12 = hours % 12 || 12;
    return `${hour12}:${minutes.toString().padStart(2, '0')} ${ampm}`;
  };

  if (!conversation) {
    return (
      <View style={styles.loadingContainer}>
        <Text>جاري التحميل...</Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView 
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={0}
    >
      {/* Header */}
<View style={styles.header}>
  <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
    <Ionicons name="arrow-forward" size={24} color={COLORS.text.primary} />
  </TouchableOpacity>
  
  <View style={styles.headerCenter}>
    <View style={styles.headerAvatar}>
      <Ionicons name="person" size={20} color={COLORS.white} />
    </View>
    <View style={styles.headerInfo}>
      <Text style={styles.headerName}>{otherUserName}</Text>
    </View>
  </View>

  <View style={styles.headerActions}>
    <TouchableOpacity style={styles.headerIcon}>
      <Ionicons name="call-outline" size={24} color={COLORS.text.primary} />
    </TouchableOpacity>
    <TouchableOpacity style={styles.headerIcon}>
      <Ionicons name="ellipsis-vertical" size={24} color={COLORS.text.primary} />
    </TouchableOpacity>
  </View>
</View>

      {/* Messages */}
      <FlatList
        ref={flatListRef}
        data={conversation.messages}
        keyExtractor={(item) => item.id}
        renderItem={renderMessage}
        contentContainerStyle={styles.messagesContainer}
        onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: false })}
      />

      {/* Input Area */}
      <View style={styles.inputContainer}>
        <TouchableOpacity style={styles.sendButton} onPress={handleSend}>
          <Ionicons name="send" size={24} color={COLORS.white} />
        </TouchableOpacity>

        <TextInput
          style={styles.input}
          placeholder="اكتب رسالتك هنا..."
          placeholderTextColor={COLORS.text.light}
          value={messageText}
          onChangeText={setMessageText}
          multiline
        />

        <TouchableOpacity style={styles.iconButton} onPress={handleSendImage}>
          <Ionicons name="add-circle-outline" size={28} color={COLORS.primary} />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.iconButton}>
          <Ionicons name="happy-outline" size={28} color={COLORS.primary} />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.white,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.md,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border.light,
    ...Platform.select({
      ios: {
        paddingTop: 50,
      },
      android: {
        paddingTop: SPACING.md,
      },
    }),
  },
  backButton: {
    padding: SPACING.sm,
  },
  headerCenter: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: SPACING.md,
  },
  headerAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  headerInfo: {
    marginRight: SPACING.sm,
  },
  headerName: {
    fontSize: FONT_SIZES.lg,
    fontWeight: 'bold',
    color: COLORS.text.primary,
  },
  headerActions: {
    flexDirection: 'row',
  },
  headerIcon: {
    padding: SPACING.sm,
    marginLeft: SPACING.xs,
  },
  messagesContainer: {
    padding: SPACING.md,
    paddingBottom: SPACING.lg,
  },
  dateDivider: {
    alignItems: 'center',
    marginVertical: SPACING.md,
  },
  dateText: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.text.light,
    backgroundColor: COLORS.border.light,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.xs,
    borderRadius: BORDER_RADIUS.md,
  },
  messageContainer: {
    flexDirection: 'row',
    marginVertical: SPACING.xs,
    alignItems: 'flex-end',
  },
  myMessageContainer: {
    justifyContent: 'flex-start',
  },
  otherMessageContainer: {
    justifyContent: 'flex-end',
  },
  otherAvatar: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: SPACING.xs,
  },
  messageBubble: {
    maxWidth: '75%',
    padding: SPACING.md,
    borderRadius: BORDER_RADIUS.lg,
  },
  myMessageBubble: {
    backgroundColor: COLORS.primary,
    borderBottomRightRadius: 4,
  },
  otherMessageBubble: {
    backgroundColor: COLORS.white,
    borderBottomLeftRadius: 4,
  },
  messageText: {
    fontSize: FONT_SIZES.md,
    lineHeight: 22,
  },
  myMessageText: {
    color: COLORS.white,
  },
  otherMessageText: {
    color: COLORS.text.primary,
  },
  messageImage: {
    width: 200,
    height: 200,
    borderRadius: BORDER_RADIUS.md,
  },
  messageFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: SPACING.xs,
  },
  timeText: {
    fontSize: FONT_SIZES.xs,
  },
  myTimeText: {
    color: COLORS.white,
    opacity: 0.8,
  },
  otherTimeText: {
    color: COLORS.text.light,
  },
  checkmark: {
    marginRight: SPACING.xs,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.white,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    borderTopWidth: 1,
    borderTopColor: COLORS.border.light,
  },
  input: {
    flex: 1,
    backgroundColor: COLORS.background,
    borderRadius: BORDER_RADIUS.xl,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    fontSize: FONT_SIZES.md,
    maxHeight: 100,
    textAlign: 'right',
  },
  iconButton: {
    padding: SPACING.sm,
    marginLeft: SPACING.xs,
  },
  sendButton: {
    backgroundColor: COLORS.primary,
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: SPACING.sm,
  },
});

export default ChatScreen;