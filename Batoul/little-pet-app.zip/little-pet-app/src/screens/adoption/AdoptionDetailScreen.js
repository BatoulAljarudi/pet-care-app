import React, { useContext, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  Dimensions,
  FlatList,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AdoptionContext } from '../../context/AdoptionContext';
import CustomHeader from '../../../components/common/CustomHeader';
import { COLORS, SPACING, FONT_SIZES, BORDER_RADIUS } from '../../utils/constants';

const { width } = Dimensions.get('window');

const AdoptionDetailScreen = ({ route, navigation }) => {
  const { petId } = route.params;
  const { getListingById, toggleFavorite, favorites, deleteListing } = useContext(AdoptionContext);
  
  const listing = getListingById(petId);
  
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const flatListRef = useRef(null);

  if (!listing) {
    return (
      <View style={styles.centerContainer}>
        <Text>الإعلان غير موجود</Text>
      </View>
    );
  }

  const isLiked = favorites.includes(listing.id);

// التحقق إذا كان الإعلان خاصاً بي
const isMyListing = listing.owner.userId === 'current_user';

  const handleContactOwner = () => {
  navigation.navigate('Chat', {
    listingId: listing.id,
    listingType: 'adoption',
    otherUserName: listing.owner.name,
  });
};

  const renderPhotoItem = ({ item }) => (
    <Image source={{ uri: item }} style={styles.photo} />
  );

  return (
    <View style={styles.container}>
      <CustomHeader
        title=""
        showBack={true}
        onBackPress={() => navigation.goBack()}
        rightIcon={isLiked ? 'heart' : 'heart-outline'}
        onRightIconPress={() => toggleFavorite(listing.id)}
      />

      <ScrollView 
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
      >
        {/* Photo Gallery */}
        <View style={styles.galleryContainer}>
          <FlatList
            ref={flatListRef}
            data={listing.photos}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            keyExtractor={(item, index) => index.toString()}
            renderItem={renderPhotoItem}
            onMomentumScrollEnd={(e) => {
              const index = Math.round(e.nativeEvent.contentOffset.x / width);
              setCurrentImageIndex(index);
            }}
          />
          
          {/* Dots Indicator */}
          <View style={styles.dotsContainer}>
            {listing.photos.map((_, index) => (
              <View
                key={index}
                style={[
                  styles.dot,
                  currentImageIndex === index && styles.dotActive,
                ]}
              />
            ))}
          </View>
        </View>

        {/* Pet Info */}
        <View style={styles.infoCard}>
          <View style={styles.nameRow}>
            <Text style={styles.petName}>{listing.name}</Text>
            <View style={styles.locationBadge}>
              <Ionicons name="location" size={16} color={COLORS.primary} />
              <Text style={styles.locationText}>{listing.city}</Text>
            </View>
          </View>

          <View style={styles.detailsGrid}>
            <View style={styles.detailItem}>
              <Ionicons name="paw" size={20} color={COLORS.primary} />
              <Text style={styles.detailLabel}>النوع</Text>
              <Text style={styles.detailValue}>{listing.petType}</Text>
            </View>

            <View style={styles.detailItem}>
              <Ionicons name="calendar" size={20} color={COLORS.primary} />
              <Text style={styles.detailLabel}>العمر</Text>
              <Text style={styles.detailValue}>{listing.age}</Text>
            </View>

            <View style={styles.detailItem}>
              <Ionicons name="male-female" size={20} color={COLORS.primary} />
              <Text style={styles.detailLabel}>الجنس</Text>
              <Text style={styles.detailValue}>{listing.gender}</Text>
            </View>

            <View style={styles.detailItem}>
              <Ionicons name="fitness" size={20} color={COLORS.primary} />
              <Text style={styles.detailLabel}>الصحة</Text>
              <Text style={styles.detailValue}>{listing.healthStatus}</Text>
            </View>
          </View>
        </View>

        {/* Breed */}
        {listing.breed && (
          <View style={styles.sectionCard}>
            <Text style={styles.sectionTitle}>السلالة</Text>
            <Text style={styles.sectionText}>{listing.breed}</Text>
          </View>
        )}

        {/* Description */}
        {listing.description && (
          <View style={styles.sectionCard}>
            <Text style={styles.sectionTitle}>الوصف</Text>
            <Text style={styles.sectionText}>{listing.description}</Text>
          </View>
        )}

        {/* Reason for Adoption */}
        {listing.reason && (
          <View style={styles.sectionCard}>
            <Text style={styles.sectionTitle}>سبب العرض للتبني</Text>
            <Text style={styles.sectionText}>{listing.reason}</Text>
          </View>
        )}

        {/* Owner Info */}
        <View style={styles.ownerCard}>
          <Text style={styles.sectionTitle}>المالك</Text>
          <View style={styles.ownerRow}>
            <View style={styles.ownerAvatar}>
              <Ionicons name="person" size={24} color={COLORS.white} />
            </View>
            <View style={styles.ownerInfo}>
              <Text style={styles.ownerName}>{listing.owner.name}</Text>
              <Text style={styles.ownerMeta}>
                {listing.owner.city} • عضو منذ {listing.owner.memberSince}
              </Text>
            </View>
          </View>
        </View>

        {/* Spacer for button */}
        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Contact/Delete Button */}
<View style={styles.footer}>
  {isMyListing ? (
    <View style={styles.myListingActions}>
      <TouchableOpacity
        style={styles.deleteButton}
        onPress={() => {
          Alert.alert(
            'حذف الإعلان',
            'هل أنت متأكد من حذف هذا الإعلان؟',
            [
              { text: 'إلغاء', style: 'cancel' },
              {
                text: 'حذف',
                style: 'destructive',
                onPress: async () => {
                  await deleteListing(listing.id);
                  Alert.alert('تم الحذف', 'تم حذف الإعلان بنجاح');
                  navigation.goBack();
                },
              },
            ]
          );
        }}
      >
        <Ionicons name="trash-outline" size={20} color={COLORS.white} />
        <Text style={styles.deleteButtonText}>حذف الإعلان</Text>
      </TouchableOpacity>
    </View>
  ) : (
    <TouchableOpacity
      style={styles.contactButton}
      onPress={handleContactOwner}
    >
      <Ionicons name="chatbubble-outline" size={20} color={COLORS.white} />
      <Text style={styles.contactButtonText}>تواصل مع المالك</Text>
    </TouchableOpacity>
  )}
</View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scrollView: {
    flex: 1,
  },
  galleryContainer: {
    position: 'relative',
    height: 300,
  },
  photo: {
    width: width,
    height: 300,
    backgroundColor: COLORS.border.light,
  },
  dotsContainer: {
    flexDirection: 'row',
    position: 'absolute',
    bottom: SPACING.lg,
    alignSelf: 'center',
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: COLORS.white,
    opacity: 0.5,
    marginHorizontal: 4,
  },
  dotActive: {
    opacity: 1,
    width: 24,
  },
  infoCard: {
    backgroundColor: COLORS.white,
    margin: SPACING.lg,
    padding: SPACING.lg,
    borderRadius: BORDER_RADIUS.lg,
  },
  nameRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.lg,
  },
  petName: {
    fontSize: FONT_SIZES.title,
    fontWeight: 'bold',
    color: COLORS.text.primary,
    flex: 1,
  },
  locationBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.background,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    borderRadius: BORDER_RADIUS.md,
  },
  locationText: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.text.secondary,
    marginRight: SPACING.xs,
  },
  detailsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  detailItem: {
    width: '48%',
    alignItems: 'center',
    backgroundColor: COLORS.background,
    padding: SPACING.md,
    borderRadius: BORDER_RADIUS.md,
    marginBottom: SPACING.sm,
  },
  detailLabel: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.text.secondary,
    marginTop: SPACING.xs,
  },
  detailValue: {
    fontSize: FONT_SIZES.md,
    fontWeight: 'bold',
    color: COLORS.text.primary,
    marginTop: SPACING.xs,
  },
  sectionCard: {
    backgroundColor: COLORS.white,
    marginHorizontal: SPACING.lg,
    marginBottom: SPACING.md,
    padding: SPACING.lg,
    borderRadius: BORDER_RADIUS.lg,
  },
  sectionTitle: {
    fontSize: FONT_SIZES.lg,
    fontWeight: 'bold',
    color: COLORS.text.primary,
    marginBottom: SPACING.md,
  },
  sectionText: {
    fontSize: FONT_SIZES.md,
    color: COLORS.text.secondary,
    lineHeight: 24,
  },
  ownerCard: {
    backgroundColor: COLORS.white,
    marginHorizontal: SPACING.lg,
    marginBottom: SPACING.md,
    padding: SPACING.lg,
    borderRadius: BORDER_RADIUS.lg,
  },
  ownerRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ownerAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: SPACING.md,
  },
  ownerInfo: {
    flex: 1,
  },
  ownerName: {
    fontSize: FONT_SIZES.lg,
    fontWeight: 'bold',
    color: COLORS.text.primary,
  },
  ownerMeta: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.text.secondary,
    marginTop: SPACING.xs,
  },
  footer: {
    backgroundColor: COLORS.white,
    padding: SPACING.lg,
    borderTopWidth: 1,
    borderTopColor: COLORS.border.light,
  },
  contactButton: {
    backgroundColor: COLORS.primary,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: SPACING.md,
    borderRadius: BORDER_RADIUS.md,
  },
  contactButtonText: {
    fontSize: FONT_SIZES.lg,
    fontWeight: 'bold',
    color: COLORS.white,
    marginRight: SPACING.sm,
  },
  myListingActions: {
  flexDirection: 'row',
  gap: SPACING.sm,
},
deleteButton: {
  flex: 1,
  backgroundColor: COLORS.status.error,
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'center',
  paddingVertical: SPACING.md,
  borderRadius: BORDER_RADIUS.md,
},
deleteButtonText: {
  fontSize: FONT_SIZES.lg,
  fontWeight: 'bold',
  color: COLORS.white,
  marginRight: SPACING.sm,
},
});

export default AdoptionDetailScreen;