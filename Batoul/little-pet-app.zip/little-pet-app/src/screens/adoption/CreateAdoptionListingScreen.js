import React, { useState, useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Image,
  Alert,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { Ionicons } from '@expo/vector-icons';
import { AdoptionContext } from '../../context/AdoptionContext';
import CustomHeader from '../../../components/common/CustomHeader';
import { COLORS, SPACING, FONT_SIZES, BORDER_RADIUS, PET_TYPES, CITIES } from '../../utils/constants';

const CreateAdoptionListingScreen = ({ navigation }) => {
  const { addListing } = useContext(AdoptionContext);
  
  const [photos, setPhotos] = useState([]);
  const [name, setName] = useState('');
  const [petType, setPetType] = useState('');
  const [breed, setBreed] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState('');
  const [city, setCity] = useState('');
  const [healthStatus, setHealthStatus] = useState('');
  const [description, setDescription] = useState('');
  const [reason, setReason] = useState('');

const pickImage = async () => {
  if (photos.length >= 5) {
    Alert.alert('تنبيه', 'يمكنك إضافة 5 صور كحد أقصى');
    return;
  }

  // طلب الصلاحيات
  const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
  
  if (status !== 'granted') {
    Alert.alert(
      'صلاحية مطلوبة',
      'نحتاج إلى صلاحية الوصول للمعرض لإضافة الصور',
      [{ text: 'حسناً' }]
    );
    return;
  }

  const result = await ImagePicker.launchImageLibraryAsync({
    mediaTypes: ImagePicker.MediaTypeOptions.Images,
    allowsEditing: true,
    aspect: [4, 3],
    quality: 0.8,
  });

  if (!result.canceled) {
    setPhotos([...photos, result.assets[0].uri]);
  }
};

  const removePhoto = (index) => {
    setPhotos(photos.filter((_, i) => i !== index));
  };

  const handleSubmit = async () => {
    // Validation
    if (!name.trim()) {
      Alert.alert('خطأ', 'يرجى إدخال اسم الأليف');
      return;
    }
    if (!petType) {
      Alert.alert('خطأ', 'يرجى اختيار نوع الأليف');
      return;
    }
    if (!city) {
      Alert.alert('خطأ', 'يرجى اختيار المدينة');
      return;
    }
    if (photos.length === 0) {
      Alert.alert('خطأ', 'يرجى إضافة صورة واحدة على الأقل');
      return;
    }

    const newListing = {
      name: name.trim(),
      petType,
      breed: breed.trim(),
      age: age.trim(),
      gender: gender || 'غير محدد',
      city,
      healthStatus: healthStatus.trim() || 'غير محدد',
      description: description.trim(),
      reason: reason.trim(),
      photos,
      owner: {
        name: 'المستخدم الحالي', // سيتم استبداله بالمستخدم الفعلي لاحقاً
        city: city,
        memberSince: new Date().getFullYear().toString(),
        userId: 'current_user', // سيتم استبداله لاحقاً
      },
    };

    await addListing(newListing);
    Alert.alert('نجح', 'تم إضافة الإعلان بنجاح', [
      { text: 'حسناً', onPress: () => navigation.goBack() }
    ]);
  };

  return (
    <View style={styles.container}>
      <CustomHeader
        title="عرض أليف للتبني"
        showBack={true}
        onBackPress={() => navigation.goBack()}
      />

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {/* Photos Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>الصور *</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={styles.photosContainer}>
              {photos.map((photo, index) => (
                <View key={index} style={styles.photoWrapper}>
                  <Image source={{ uri: photo }} style={styles.photoPreview} />
                  <TouchableOpacity
                    style={styles.removePhotoButton}
                    onPress={() => removePhoto(index)}
                  >
                    <Ionicons name="close-circle" size={24} color={COLORS.status.error} />
                  </TouchableOpacity>
                </View>
              ))}
              {photos.length < 5 && (
                <TouchableOpacity style={styles.addPhotoButton} onPress={pickImage}>
                  <Ionicons name="camera" size={32} color={COLORS.primary} />
                  <Text style={styles.addPhotoText}>إضافة صورة</Text>
                </TouchableOpacity>
              )}
            </View>
          </ScrollView>
        </View>

        {/* Basic Info */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>المعلومات الأساسية</Text>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>الاسم *</Text>
            <TextInput
              style={styles.input}
              placeholder="اسم الأليف"
              value={name}
              onChangeText={setName}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>النوع *</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={styles.chipsContainer}>
                {PET_TYPES.filter(type => type !== 'الكل').map((type) => (
                  <TouchableOpacity
                    key={type}
                    style={[
                      styles.chip,
                      petType === type && styles.chipActive,
                    ]}
                    onPress={() => setPetType(type)}
                  >
                    <Text style={[
                      styles.chipText,
                      petType === type && styles.chipTextActive,
                    ]}>
                      {type}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>السلالة</Text>
            <TextInput
              style={styles.input}
              placeholder="مثال: شيرازي، جولدن ريتريفر"
              value={breed}
              onChangeText={setBreed}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>العمر</Text>
            <TextInput
              style={styles.input}
              placeholder="مثال: 6 أشهر، سنتان"
              value={age}
              onChangeText={setAge}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>الجنس</Text>
            <View style={styles.chipsContainer}>
              {['ذكر', 'أنثى'].map((g) => (
                <TouchableOpacity
                  key={g}
                  style={[
                    styles.chip,
                    gender === g && styles.chipActive,
                  ]}
                  onPress={() => setGender(g)}
                >
                  <Text style={[
                    styles.chipText,
                    gender === g && styles.chipTextActive,
                  ]}>
                    {g}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>المدينة *</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              <View style={styles.chipsContainer}>
                {CITIES.filter(c => c !== 'الكل').map((c) => (
                  <TouchableOpacity
                    key={c}
                    style={[
                      styles.chip,
                      city === c && styles.chipActive,
                    ]}
                    onPress={() => setCity(c)}
                  >
                    <Text style={[
                      styles.chipText,
                      city === c && styles.chipTextActive,
                    ]}>
                      {c}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </ScrollView>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>الحالة الصحية</Text>
            <TextInput
              style={styles.input}
              placeholder="مثال: سليم، محصن، معقم"
              value={healthStatus}
              onChangeText={setHealthStatus}
            />
          </View>
        </View>

        {/* Additional Info */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>معلومات إضافية</Text>
          
          <View style={styles.inputGroup}>
            <Text style={styles.label}>الوصف</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="صف شخصية الأليف وعاداته..."
              value={description}
              onChangeText={setDescription}
              multiline
              numberOfLines={4}
            />
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>سبب العرض للتبني</Text>
            <TextInput
              style={[styles.input, styles.textArea]}
              placeholder="لماذا تعرض هذا الأليف للتبني؟"
              value={reason}
              onChangeText={setReason}
              multiline
              numberOfLines={3}
            />
          </View>
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* Submit Button */}
      <View style={styles.footer}>
        <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
          <Text style={styles.submitButtonText}>نشر الإعلان</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scrollView: {
    flex: 1,
  },
  section: {
    padding: SPACING.lg,
  },
  sectionTitle: {
    fontSize: FONT_SIZES.xl,
    fontWeight: 'bold',
    color: COLORS.text.primary,
    marginBottom: SPACING.md,
  },
  photosContainer: {
    flexDirection: 'row',
  },
  photoWrapper: {
    position: 'relative',
    marginLeft: SPACING.sm,
  },
  photoPreview: {
    width: 100,
    height: 100,
    borderRadius: BORDER_RADIUS.md,
    backgroundColor: COLORS.border.light,
  },
  removePhotoButton: {
    position: 'absolute',
    top: -8,
    left: -8,
    backgroundColor: COLORS.white,
    borderRadius: 12,
  },
  addPhotoButton: {
    width: 100,
    height: 100,
    borderRadius: BORDER_RADIUS.md,
    borderWidth: 2,
    borderColor: COLORS.primary,
    borderStyle: 'dashed',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: SPACING.sm,
  },
  addPhotoText: {
    fontSize: FONT_SIZES.sm,
    color: COLORS.primary,
    marginTop: SPACING.xs,
  },
  inputGroup: {
    marginBottom: SPACING.lg,
  },
  label: {
    fontSize: FONT_SIZES.md,
    fontWeight: 'bold',
    color: COLORS.text.primary,
    marginBottom: SPACING.sm,
  },
  input: {
    backgroundColor: COLORS.white,
    borderRadius: BORDER_RADIUS.md,
    padding: SPACING.md,
    fontSize: FONT_SIZES.md,
    color: COLORS.text.primary,
    borderWidth: 1,
    borderColor: COLORS.border.light,
    textAlign: 'right',
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  chipsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  chip: {
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.sm,
    borderRadius: BORDER_RADIUS.xl,
    backgroundColor: COLORS.background,
    marginLeft: SPACING.sm,
    marginBottom: SPACING.sm,
    borderWidth: 1,
    borderColor: COLORS.border.light,
  },
  chipActive: {
    backgroundColor: COLORS.primary,
    borderColor: COLORS.primary,
  },
  chipText: {
    fontSize: FONT_SIZES.md,
    color: COLORS.text.secondary,
  },
  chipTextActive: {
    color: COLORS.white,
    fontWeight: 'bold',
  },
  footer: {
    backgroundColor: COLORS.white,
    padding: SPACING.lg,
    borderTopWidth: 1,
    borderTopColor: COLORS.border.light,
  },
  submitButton: {
    backgroundColor: COLORS.primary,
    paddingVertical: SPACING.md,
    borderRadius: BORDER_RADIUS.md,
    alignItems: 'center',
  },
  submitButtonText: {
    fontSize: FONT_SIZES.lg,
    fontWeight: 'bold',
    color: COLORS.white,
  },
});

export default CreateAdoptionListingScreen;