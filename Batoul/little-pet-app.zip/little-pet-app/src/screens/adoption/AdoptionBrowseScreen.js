import React, { useState, useContext, useRef } from 'react';
import {
  View,
  FlatList,
  StyleSheet,
  ActivityIndicator,
  RefreshControl,
  Animated,
} from 'react-native';
import { AdoptionContext } from '../../context/AdoptionContext';
import PetCard from '../../../components/adoption/PetCard';
import AdoptionFilters from '../../../components/adoption/AdoptionFilters';
import CustomHeader from '../../../components/common/CustomHeader';
import TabSwitch from '../../../components/common/TabSwitch';
import SearchBar from '../../../components/common/SearchBar';
import FilterModal from '../../../components/common/FilterModal';
import { COLORS, SPACING } from '../../utils/constants';

const AdoptionBrowseScreen = ({ navigation }) => {
  const { adoptionListings, loading, favorites, toggleFavorite, refreshListings } = useContext(AdoptionContext);
  
  const [activeTab, setActiveTab] = useState('تصفح المعروض');
  const [selectedType, setSelectedType] = useState('الكل');
  const [searchQuery, setSearchQuery] = useState('');
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [filters, setFilters] = useState({
    city: 'الكل',
    gender: 'الكل',
    favoritesOnly: false,
  });
  const [refreshing, setRefreshing] = useState(false);

  // Animation for hiding/showing filters
  const scrollY = useRef(new Animated.Value(0)).current;
  const filterHeight = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [0, -200], // إخفاء 200px عند Scroll
    extrapolate: 'clamp',
  });

  // Filter listings
  // Filter listings
const filteredListings = adoptionListings.filter(listing => {
  // Filter by Tab
  if (activeTab === 'أعرض للتبني') {
    // عرض إعلاناتي الشخصية فقط
    if (listing.owner.userId !== 'current_user') {
      return false;
    }
  } else {
    // تصفح المعروض - عرض إعلانات الآخرين فقط
    if (listing.owner.userId === 'current_user') {
      return false;
    }
  }

  // Favorites filter
  if (filters.favoritesOnly && !favorites.includes(listing.id)) {
    return false;
  }
  
  // Type filter
  if (selectedType !== 'الكل' && listing.petType !== selectedType) {
    return false;
  }
  
  // City filter
  if (filters.city !== 'الكل' && listing.city !== filters.city) {
    return false;
  }
  
  // Gender filter
  if (filters.gender !== 'الكل' && listing.gender !== filters.gender) {
    return false;
  }
  
  // Search filter
  if (searchQuery && !listing.name.toLowerCase().includes(searchQuery.toLowerCase())) {
    return false;
  }
  
  return true;
});

  const onRefresh = async () => {
    setRefreshing(true);
    await refreshListings();
    setRefreshing(false);
  };

  const handlePetPress = (petId) => {
    navigation.navigate('AdoptionDetail', { petId });
  };

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color={COLORS.primary} />
      </View>
    );
  }

  return (
  <View style={styles.container}>
    <CustomHeader
      title="تبني أليف جديد"
      showBack={true}          
  onBackPress={() => {}}
  showNotification={true}
  onNotificationPress={() => {}}
    />
    
    <View style={styles.content}>
      <Animated.View 
        style={[
          styles.filtersContainer,
          { transform: [{ translateY: filterHeight }] }
        ]}
      >
        <TabSwitch
          tabs={['تصفح المعروض', 'أعرض للتبني']}
          activeTab={activeTab}
          onTabChange={setActiveTab}
        />
        
        <SearchBar
          placeholder="ابحث عن أليف..."
          value={searchQuery}
          onChangeText={setSearchQuery}
          showFilter={true}
          onFilterPress={() => setShowFilterModal(true)}
        />
        
        <AdoptionFilters 
          selectedType={selectedType}
          onTypeChange={setSelectedType}
        />
      </Animated.View>
      
      <FlatList
  data={filteredListings}
  keyExtractor={(item) => item.id}
  numColumns={2}
  columnWrapperStyle={styles.row}
  contentContainerStyle={[
    styles.listContent,
    { paddingTop: 200 } // ← أضف هذا
  ]}
  showsVerticalScrollIndicator={false}
  onScroll={Animated.event(
    [{ nativeEvent: { contentOffset: { y: scrollY } } }],
    { useNativeDriver: true }
  )}
  scrollEventThrottle={16}
  renderItem={({ item }) => (
    <PetCard 
      pet={item}
      onPress={() => handlePetPress(item.id)}
      onLikePress={() => toggleFavorite(item.id)}
      isLiked={favorites.includes(item.id)}
    />
  )}
  refreshControl={
    <RefreshControl 
      refreshing={refreshing}
      onRefresh={onRefresh}
      colors={[COLORS.primary]}
    />
  }
/>
    </View>
    
    <FilterModal
      visible={showFilterModal}
      onClose={() => setShowFilterModal(false)}
      filters={filters}
      onApply={(newFilters) => {
        setFilters(newFilters);
        setShowFilterModal(false);
      }}
    />
  </View>
);
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.background,
  },
  content: {
    flex: 1,
    overflow: 'hidden',
  },
  filtersContainer: {
    backgroundColor: COLORS.background,
    zIndex: 10,
    position: 'absolute', // ← أضف هذا
    top: 0,               // ← أضف هذا
    left: 0,              // ← أضف هذا
    right: 0,             // ← أضف هذا
  },
  listContent: {
    padding: SPACING.lg,
    paddingBottom: 100,
    paddingTop: 200, // ← أضف هذا (ارتفاع الفلاتر تقريباً)
  },
  row: {
    justifyContent: 'space-between',
  },
});

export default AdoptionBrowseScreen;