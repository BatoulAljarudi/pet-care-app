// App Constants and Theme
export const COLORS = {
  primary: '#5B8A5F',
  primaryDark: '#4A7350',
  primaryLight: '#6FA073',
  
  secondary: '#E8A87C',
  
  background: '#F9F9F9',
  white: '#FFFFFF',
  
  text: {
    primary: '#333333',
    secondary: '#666666',
    light: '#999999',
    white: '#FFFFFF',
  },
  
  border: {
    light: '#F0F0F0',
    medium: '#E0E0E0',
    dark: '#CCCCCC',
  },
  
  status: {
    success: '#4CAF50',
    error: '#F44336',
    warning: '#FF9800',
    info: '#2196F3',
  },
  
  chat: {
    sent: '#5B8A5F',
    received: '#F5F5F5',
  }
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
};

export const FONT_SIZES = {
  xs: 10,
  sm: 12,
  md: 14,
  lg: 16,
  xl: 18,
  xxl: 20,
  title: 24,
};

export const BORDER_RADIUS = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  round: 50,
};

export const PET_TYPES = ['الكل', 'قطط', 'كلاب', 'طيور', 'صقور', 'أخرى'];

export const CITIES = ['الكل', 'الرياض', 'جدة', 'الدمام', 'مكة', 'المدينة'];