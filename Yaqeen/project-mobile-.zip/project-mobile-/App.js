import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Alert,
  Linking,
  StyleSheet,
  ScrollView,
  Switch,
  Image,
  Modal,
} from "react-native";

import MapView, { Marker } from "react-native-maps";
import * as Location from "expo-location";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as ImagePicker from "expo-image-picker";

const defaultImage =
  "https://images.unsplash.com/photo-1576201836106-db1758fd1c97?w=800";

const placesData = [
  {
    id: "1",
    name: "عيادة الأليف الصحية",
    type: "عيادة بيطرية",
    city: "القطيف",
    latitude: 26.5652,
    longitude: 50.0089,
    rating: 4.5,
    phone: "0501234567",
    address: "حي البحر، القطيف",
    open: true,
    wait: "١٥ دقيقة",
    price: "$$$",
    services: ["تطعيمات", "فحوصات دورية", "طوارئ", "عناية عامة"],
    active: true,
    image: defaultImage,
  },
  {
    id: "2",
    name: "متجر الأليف",
    type: "متجر مستلزمات",
    city: "الدمام",
    latitude: 26.4207,
    longitude: 50.0888,
    rating: 4.3,
    phone: "0559876543",
    address: "حي الشاطئ، الدمام",
    open: true,
    wait: "متاح",
    price: "$$",
    services: ["طعام", "ألعاب", "مستلزمات", "رمل قطط"],
    active: true,
    image:
      "https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=800",
  },
  {
    id: "3",
    name: "صالون عناية الأليف",
    type: "صالون تجميل",
    city: "الخبر",
    latitude: 26.2172,
    longitude: 50.1971,
    rating: 4.8,
    phone: "0562223344",
    address: "شارع الأمير سلطان، الخبر",
    open: false,
    wait: "٣٠ دقيقة",
    price: "$$$",
    services: ["استحمام", "قص أظافر", "تنظيف", "تصفيف"],
    active: true,
    image:
      "https://images.unsplash.com/photo-1537151608828-ea2b11777ee8?w=800",
  },
];

const reportsData = [
  {
    id: "1",
    user: "مشاعل الهاجري",
    reason: "معلومات طبية خاطئة",
    time: "قبل ٢٠ دقيقة",
    post:
      "الغذاء المناسب للقطط الصغيرة في فصل الصيف بدون الرجوع لمصدر طبي موثوق...",
    status: "pending",
  },
  {
    id: "2",
    user: "أحمد منصور",
    reason: "سب وشتم",
    time: "منذ ساعة",
    post: "تعليق غير مناسب تجاه المستخدمين في المجتمع...",
    status: "pending",
  },
  {
    id: "3",
    user: "سارة الكواري",
    reason: "سبام / تكرار",
    time: "منذ ٣ ساعات",
    post: "تكرار محتوى تسويقي في أكثر من منشور...",
    status: "resolved",
  },
];

const calculateDistance = (lat1, lon1, lat2, lon2) => {
  const toRad = (value) => (value * Math.PI) / 180;
  const R = 6371;

  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return Number((R * c).toFixed(1));
};

export default function App() {
  const [screen, setScreen] = useState("map");
  const [selectedPlace, setSelectedPlace] = useState(null);
  const [places, setPlaces] = useState(placesData);
  const [reports, setReports] = useState(reportsData);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    AsyncStorage.setItem("places", JSON.stringify(places));
  }, [places]);

  useEffect(() => {
    AsyncStorage.setItem("reports", JSON.stringify(reports));
  }, [reports]);

  const loadData = async () => {
    const savedPlaces = await AsyncStorage.getItem("places");
    const savedReports = await AsyncStorage.getItem("reports");

    if (savedPlaces) {
      setPlaces(JSON.parse(savedPlaces));
    } else {
      await AsyncStorage.setItem("places", JSON.stringify(placesData));
    }

    if (savedReports) {
      setReports(JSON.parse(savedReports));
    } else {
      await AsyncStorage.setItem("reports", JSON.stringify(reportsData));
    }
  };

  const openDetail = (place) => {
    setSelectedPlace(place);
    setScreen("detail");
  };

  return (
    <View style={{ flex: 1 }}>
      {screen === "map" && (
        <MapScreen
          places={places}
          openDetail={openDetail}
          setScreen={setScreen}
        />
      )}

      {screen === "detail" && (
        <DetailScreen place={selectedPlace} setScreen={setScreen} />
      )}

      {screen === "manage" && (
        <ManagePlacesScreen
          places={places}
          setPlaces={setPlaces}
          setScreen={setScreen}
        />
      )}

      {screen === "reports" && (
        <ReportsScreen
          reports={reports}
          setReports={setReports}
          setScreen={setScreen}
        />
      )}
    </View>
  );
}

function MapScreen({ places, openDetail, setScreen }) {
  const [location, setLocation] = useState(null);
  const [search, setSearch] = useState("");
  const [selectedMarker, setSelectedMarker] = useState(null);
  const [typeFilter, setTypeFilter] = useState("all");
  const [sortType, setSortType] = useState("none");

  useEffect(() => {
    getUserLocation();
  }, []);

  const getUserLocation = async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();

    if (status !== "granted") {
      Alert.alert("تنبيه", "يجب السماح بالوصول للموقع.");
      return;
    }

    const loc = await Location.getCurrentPositionAsync({});
    setLocation(loc.coords);
  };

  let filteredPlaces = places.filter((p) => {
    const searchMatch = p.name.includes(search) || p.type.includes(search);
    const typeMatch = typeFilter === "all" || p.type === typeFilter;

    return p.active && searchMatch && typeMatch;
  });

  if (sortType === "open") {
    filteredPlaces = filteredPlaces.filter((p) => p.open);
  }

  if (sortType === "top") {
    filteredPlaces = [...filteredPlaces].sort((a, b) => b.rating - a.rating);
  }

  if (sortType === "nearest" && location) {
    filteredPlaces = [...filteredPlaces].sort((a, b) => {
      const distA = calculateDistance(
        location.latitude,
        location.longitude,
        Number(a.latitude),
        Number(a.longitude)
      );

      const distB = calculateDistance(
        location.latitude,
        location.longitude,
        Number(b.latitude),
        Number(b.longitude)
      );

      return distA - distB;
    });
  }

  const getDistanceText = (place) => {
    if (!location) return "غير محدد";

    const distance = calculateDistance(
      location.latitude,
      location.longitude,
      Number(place.latitude),
      Number(place.longitude)
    );

    return `${distance} كم`;
  };

  return (
    <View style={{ flex: 1 }}>
      <MapView
        style={{ flex: 1 }}
        initialRegion={{
          latitude: 26.5652,
          longitude: 50.0089,
          latitudeDelta: 0.25,
          longitudeDelta: 0.25,
        }}
        region={
          location
            ? {
                latitude: location.latitude,
                longitude: location.longitude,
                latitudeDelta: 0.25,
                longitudeDelta: 0.25,
              }
            : undefined
        }
      >
        {location && (
          <Marker
            coordinate={{
              latitude: location.latitude,
              longitude: location.longitude,
            }}
            title="موقعي"
            pinColor="blue"
          />
        )}

        {filteredPlaces.map((place) => (
          <Marker
            key={place.id}
            coordinate={{
              latitude: Number(place.latitude),
              longitude: Number(place.longitude),
            }}
            title={place.name}
            description={place.type}
            pinColor={
              place.type === "عيادة بيطرية"
                ? "red"
                : place.type === "متجر مستلزمات"
                ? "orange"
                : "green"
            }
            onPress={() => setSelectedMarker(place)}
          />
        ))}
      </MapView>

      <View style={styles.mapTop}>
        <View style={styles.searchBox}>
          <Text style={styles.searchIcon}>🔍</Text>
          <TextInput
            placeholder="ابحث عن عيادة بيطرية..."
            value={search}
            onChangeText={setSearch}
            style={styles.searchInput}
            textAlign="right"
          />
        </View>

        <View style={styles.mapTabs}>
          {[
            ["all", "الكل"],
            ["عيادة بيطرية", "عيادات"],
            ["متجر مستلزمات", "متاجر"],
            ["صالون تجميل", "صالونات"],
          ].map(([value, label]) => (
            <TouchableOpacity
              key={value}
              style={[
                styles.mapTab,
                typeFilter === value && styles.activeGreenTab,
              ]}
              onPress={() => setTypeFilter(value)}
            >
              <Text
                style={
                  typeFilter === value ? styles.whiteText : styles.greenText
                }
              >
                {label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.filterRow}>
          <TouchableOpacity
            style={[
              styles.filterBtn,
              sortType === "open" && styles.activeSoftBtn,
            ]}
            onPress={() => setSortType(sortType === "open" ? "none" : "open")}
          >
            <Text style={styles.darkText}>مفتوح الآن</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.filterBtn,
              sortType === "nearest" && styles.activeSoftBtn,
            ]}
            onPress={() =>
              setSortType(sortType === "nearest" ? "none" : "nearest")
            }
          >
            <Text style={styles.darkText}>الأقرب</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.filterBtn,
              sortType === "top" && styles.activeSoftBtn,
            ]}
            onPress={() => setSortType(sortType === "top" ? "none" : "top")}
          >
            <Text style={styles.darkText}>الأعلى تقييماً</Text>
          </TouchableOpacity>
        </View>
      </View>

      <TouchableOpacity style={styles.myLocationBtn} onPress={getUserLocation}>
        <Text>📍</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.adminFloat} onPress={() => setScreen("manage")}>
        <Text style={styles.whiteText}>إدارة المواقع</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.reportFloat} onPress={() => setScreen("reports")}>
        <Text style={styles.whiteText}>البلاغات</Text>
      </TouchableOpacity>

      {selectedMarker && (
        <View style={styles.placeSheet}>
          <View style={styles.sheetHandle} />

          <View style={styles.placeHeader}>
            <Image
              source={{ uri: selectedMarker.image || defaultImage }}
              style={styles.placeLogo}
            />

            <View style={{ flex: 1 }}>
              <Text style={styles.placeName}>{selectedMarker.name}</Text>
              <Text style={styles.placeType}>{selectedMarker.type}</Text>
              <Text style={styles.placeInfo}>
                ⭐ {selectedMarker.rating} • {getDistanceText(selectedMarker)}
              </Text>
              <Text style={styles.openText}>
                {selectedMarker.open ? "مفتوح الآن" : "مغلق الآن"}
              </Text>
            </View>
          </View>

          <View style={styles.statsRow}>
            <View style={styles.statBox}>
              <Text style={styles.statLabel}>الأسعار</Text>
              <Text style={styles.statValue}>{selectedMarker.price}</Text>
            </View>

            <View style={styles.statBox}>
              <Text style={styles.statLabel}>الخدمات</Text>
              <Text style={styles.statValue}>
                {selectedMarker.services.length}+ خدمة
              </Text>
            </View>

            <View style={styles.statBox}>
              <Text style={styles.statLabel}>الانتظار</Text>
              <Text style={styles.statValue}>{selectedMarker.wait}</Text>
            </View>
          </View>

          <View style={styles.actionRow}>
            <TouchableOpacity
              style={styles.callBtn}
              onPress={() => Linking.openURL(`tel:${selectedMarker.phone}`)}
            >
              <Text style={styles.greenText}>اتصال سريع</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.directionBtn}
              onPress={() => openDetail(selectedMarker)}
            >
              <Text style={styles.whiteText}>عرض التفاصيل</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );
}

function DetailScreen({ place, setScreen }) {
  const openDirections = () => {
    const url = `https://www.google.com/maps/search/?api=1&query=${place.latitude},${place.longitude}`;
    Linking.openURL(url);
  };

  return (
    <ScrollView style={styles.page}>
      <TouchableOpacity onPress={() => setScreen("map")}>
        <Text style={styles.back}>← رجوع</Text>
      </TouchableOpacity>

      <Image source={{ uri: place.image || defaultImage }} style={styles.detailImage} />

      <Text style={styles.bigTitle}>{place.name}</Text>
      <Text style={styles.typeText}>{place.type}</Text>
      <Text style={styles.infoText}>⭐ {place.rating}</Text>
      <Text style={styles.infoText}>📍 {place.address}</Text>
      <Text style={styles.infoText}>📞 {place.phone}</Text>

      <Text style={styles.openText}>
        {place.open ? "مفتوح الآن" : "مغلق الآن"}
      </Text>

      <Text style={styles.sectionTitle}>ساعات العمل</Text>
      <View style={styles.hoursBox}>
        {[
          "الأحد: ٩:٠٠ ص - ١٠:٠٠ م",
          "الإثنين: ٩:٠٠ ص - ١٠:٠٠ م",
          "الثلاثاء: ٩:٠٠ ص - ١٠:٠٠ م",
          "الأربعاء: ٩:٠٠ ص - ١٠:٠٠ م",
          "الخميس: ٩:٠٠ ص - ١٠:٠٠ م",
          "الجمعة: ٤:٠٠ م - ١٠:٠٠ م",
          "السبت: ١٠:٠٠ ص - ٩:٠٠ م",
        ].map((item) => (
          <Text key={item} style={styles.normalText}>
            {item}
          </Text>
        ))}
      </View>

      <Text style={styles.sectionTitle}>الخدمات المقدمة</Text>
      {place.services.map((service, index) => (
        <Text key={index} style={styles.normalText}>
          • {service}
        </Text>
      ))}

      <TouchableOpacity style={styles.greenButton} onPress={openDirections}>
        <Text style={styles.whiteText}>الحصول على الاتجاهات</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.blueButton}
        onPress={() => Linking.openURL(`tel:${place.phone}`)}
      >
        <Text style={styles.whiteText}>الاتصال الآن</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

function ManagePlacesScreen({ places, setPlaces, setScreen }) {
  const emptyForm = {
    id: "",
    name: "",
    type: "عيادة بيطرية",
    city: "",
    address: "",
    phone: "",
    latitude: "",
    longitude: "",
    services: "",
    image: "",
    open: true,
    active: true,
  };

  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("عيادة بيطرية");
  const [modalVisible, setModalVisible] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [isEdit, setIsEdit] = useState(false);

  const filtered = places.filter(
    (p) =>
      p.type === filter &&
      (p.name.includes(search) || p.city.includes(search))
  );

  const openAddForm = () => {
    setForm(emptyForm);
    setIsEdit(false);
    setModalVisible(true);
  };

  const openEditForm = (place) => {
    setForm({
      ...place,
      latitude: String(place.latitude),
      longitude: String(place.longitude),
      services: place.services.join(", "),
    });
    setIsEdit(true);
    setModalVisible(true);
  };

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 1,
    });

    if (!result.canceled) {
      setForm({ ...form, image: result.assets[0].uri });
    }
  };

  const savePlace = () => {
    if (
      !form.name ||
      !form.city ||
      !form.address ||
      !form.phone ||
      !form.latitude ||
      !form.longitude
    ) {
      Alert.alert("تنبيه", "يرجى تعبئة جميع البيانات الأساسية.");
      return;
    }

    const placeData = {
      ...form,
      id: isEdit ? form.id : Date.now().toString(),
      latitude: Number(form.latitude),
      longitude: Number(form.longitude),
      rating: isEdit ? form.rating : 4.5,
      wait: isEdit ? form.wait : "١٥ دقيقة",
      price: isEdit ? form.price : "$$",
      services: form.services
        ? form.services.split(",").map((s) => s.trim())
        : [],
      image: form.image || defaultImage,
      active: form.active,
      open: form.open,
    };

    if (isEdit) {
      setPlaces(places.map((p) => (p.id === form.id ? placeData : p)));
      Alert.alert("تم", "تم تعديل المكان بنجاح.");
    } else {
      setPlaces([...places, placeData]);
      Alert.alert("تم", "تم إضافة المكان بنجاح.");
    }

    setModalVisible(false);
  };

  const deletePlace = (id) => {
    Alert.alert("حذف المكان", "هل أنتِ متأكدة من حذف هذا المكان؟", [
      { text: "إلغاء" },
      {
        text: "حذف",
        onPress: () => setPlaces(places.filter((p) => p.id !== id)),
      },
    ]);
  };

  const toggleActive = (id) => {
    setPlaces(
      places.map((p) => (p.id === id ? { ...p, active: !p.active } : p))
    );
  };

  return (
    <View style={styles.adminPage}>
      <ScrollView>
        <TouchableOpacity onPress={() => setScreen("map")}>
          <Text style={styles.back}>← رجوع</Text>
        </TouchableOpacity>

        <Text style={styles.adminHeader}>لوحة التحكم</Text>
        <Text style={styles.bigTitle}>إدارة الأماكن على الخريطة</Text>
        <Text style={styles.subtitle}>
          إدارة العيادات والمتاجر والصالونات الخاصة بالحيوانات الأليفة.
        </Text>

        <TextInput
          placeholder="البحث في الأماكن..."
          value={search}
          onChangeText={setSearch}
          style={styles.adminSearch}
          textAlign="right"
        />

        <TouchableOpacity style={styles.addPlaceBtn} onPress={openAddForm}>
          <Text style={styles.whiteText}>+ Add New Place</Text>
        </TouchableOpacity>

        <View style={styles.adminTabs}>
          {["عيادة بيطرية", "متجر مستلزمات", "صالون تجميل"].map((item) => (
            <TouchableOpacity
              key={item}
              style={[styles.adminTab, filter === item && styles.adminActiveTab]}
              onPress={() => setFilter(item)}
            >
              <Text style={filter === item ? styles.whiteText : styles.greenText}>
                {item}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <View style={styles.countCard}>
          <Text style={styles.countLabel}>إجمالي المواقع</Text>
          <Text style={styles.countNumberWhite}>{filtered.length}</Text>
        </View>

        <FlatList
          data={filtered}
          keyExtractor={(item) => item.id}
          scrollEnabled={false}
          renderItem={({ item }) => (
            <View style={styles.adminCard}>
              <Image
                source={{ uri: item.image || defaultImage }}
                style={styles.adminImage}
              />

              <View style={{ flex: 1 }}>
                <Text style={styles.cardTitle}>{item.name}</Text>
                <Text style={styles.cardText}>{item.type}</Text>
                <Text style={styles.cardText}>{item.city}</Text>
                <Text style={styles.cardText}>{item.address}</Text>

                <Text style={styles.badge}>
                  {item.active ? "نشط" : "غير نشط"}
                </Text>

                <View style={styles.adminActions}>
                  <TouchableOpacity
                    style={styles.deleteSmall}
                    onPress={() => deletePlace(item.id)}
                  >
                    <Text style={styles.deleteText}>Delete</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={styles.editSmall}
                    onPress={() => openEditForm(item)}
                  >
                    <Text style={styles.greenText}>Edit</Text>
                  </TouchableOpacity>

                  <Switch
                    value={item.active}
                    onValueChange={() => toggleActive(item.id)}
                  />
                </View>
              </View>
            </View>
          )}
        />

        <TouchableOpacity style={styles.loadMore}>
          <Text style={styles.greenText}>تحميل المزيد من المواقع</Text>
        </TouchableOpacity>
      </ScrollView>

      <Modal visible={modalVisible} animationType="slide">
        <ScrollView style={styles.page}>
          <TouchableOpacity onPress={() => setModalVisible(false)}>
            <Text style={styles.back}>← رجوع</Text>
          </TouchableOpacity>

          <Text style={styles.bigTitle}>
            {isEdit ? "تعديل المكان" : "إضافة مكان جديد"}
          </Text>

          <TouchableOpacity style={styles.imagePickerBtn} onPress={pickImage}>
            <Text style={styles.greenText}>اختيار صورة</Text>
          </TouchableOpacity>

          {form.image ? (
            <Image source={{ uri: form.image }} style={styles.previewImage} />
          ) : null}

          <FormInput
            label="اسم المكان"
            value={form.name}
            onChangeText={(v) => setForm({ ...form, name: v })}
          />

          <Text style={styles.formLabel}>النوع</Text>
          <View style={styles.typeChoices}>
            {["عيادة بيطرية", "متجر مستلزمات", "صالون تجميل"].map((t) => (
              <TouchableOpacity
                key={t}
                style={[
                  styles.choiceBtn,
                  form.type === t && styles.activeGreenTab,
                ]}
                onPress={() => setForm({ ...form, type: t })}
              >
                <Text style={form.type === t ? styles.whiteText : styles.greenText}>
                  {t}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <FormInput
            label="المدينة"
            value={form.city}
            onChangeText={(v) => setForm({ ...form, city: v })}
          />

          <FormInput
            label="العنوان"
            value={form.address}
            onChangeText={(v) => setForm({ ...form, address: v })}
          />

          <FormInput
            label="رقم الهاتف"
            value={form.phone}
            onChangeText={(v) => setForm({ ...form, phone: v })}
            keyboardType="phone-pad"
          />

          <FormInput
            label="Latitude"
            value={form.latitude}
            onChangeText={(v) => setForm({ ...form, latitude: v })}
            keyboardType="numeric"
          />

          <FormInput
            label="Longitude"
            value={form.longitude}
            onChangeText={(v) => setForm({ ...form, longitude: v })}
            keyboardType="numeric"
          />

          <FormInput
            label="الخدمات المقدمة"
            placeholder="مثال: تطعيمات, فحوصات, طوارئ"
            value={form.services}
            onChangeText={(v) => setForm({ ...form, services: v })}
          />

          <View style={styles.switchLine}>
            <Text style={styles.formLabel}>مفتوح الآن</Text>
            <Switch
              value={form.open}
              onValueChange={(v) => setForm({ ...form, open: v })}
            />
          </View>

          <TouchableOpacity style={styles.greenButton} onPress={savePlace}>
            <Text style={styles.whiteText}>
              {isEdit ? "حفظ التعديل" : "حفظ المكان"}
            </Text>
          </TouchableOpacity>
        </ScrollView>
      </Modal>
    </View>
  );
}

function FormInput({ label, ...props }) {
  return (
    <View>
      <Text style={styles.formLabel}>{label}</Text>
      <TextInput {...props} style={styles.formInput} textAlign="right" />
    </View>
  );
}

function ReportsScreen({ reports, setReports, setScreen }) {
  const [filter, setFilter] = useState("pending");

  const resolveReport = (id) => {
    setReports(
      reports.map((r) => (r.id === id ? { ...r, status: "resolved" } : r))
    );
  };

  const removePost = (id) => {
    Alert.alert("إزالة المنشور", "هل أنتِ متأكدة من إزالة هذا المنشور؟", [
      { text: "إلغاء" },
      {
        text: "إزالة",
        onPress: () => resolveReport(id),
      },
    ]);
  };

  const filtered = reports.filter((r) => r.status === filter);

  return (
    <ScrollView style={styles.adminPage}>
      <TouchableOpacity onPress={() => setScreen("map")}>
        <Text style={styles.back}>← رجوع</Text>
      </TouchableOpacity>

      <Text style={styles.adminHeader}>لوحة التحكم</Text>
      <Text style={styles.bigTitle}>البلاغات</Text>
      <Text style={styles.subtitle}>
        مراجعة المنشورات المبلغ عنها واتخاذ الإجراء المناسب.
      </Text>

      <View style={styles.reportStats}>
        <View style={styles.reportStatBox}>
          <Text style={styles.countNumber}>
            {reports.filter((r) => r.status === "pending").length}
          </Text>
          <Text style={styles.statLabel}>بلاغات معلقة</Text>
        </View>

        <View style={styles.reportStatBox}>
          <Text style={styles.countNumber}>
            {reports.filter((r) => r.status === "resolved").length}
          </Text>
          <Text style={styles.statLabel}>تمت معالجتها</Text>
        </View>
      </View>

      <View style={styles.adminTabs}>
        <TouchableOpacity
          style={[styles.adminTab, filter === "pending" && styles.adminActiveTab]}
          onPress={() => setFilter("pending")}
        >
          <Text style={filter === "pending" ? styles.whiteText : styles.greenText}>
            Pending
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.adminTab, filter === "resolved" && styles.adminActiveTab]}
          onPress={() => setFilter("resolved")}
        >
          <Text style={filter === "resolved" ? styles.whiteText : styles.greenText}>
            Resolved
          </Text>
        </TouchableOpacity>
      </View>

      {filtered.length === 0 ? (
        <Text style={styles.empty}>لا توجد بلاغات حالياً</Text>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => item.id}
          scrollEnabled={false}
          renderItem={({ item }) => (
            <View style={styles.reportCard}>
              <View style={styles.reportTop}>
                <Text style={styles.cardTitle}>{item.user}</Text>
                <Text style={styles.reportTag}>
                  {item.status === "pending" ? "معلق" : "محلول"}
                </Text>
              </View>

              <Text style={styles.cardText}>{item.time}</Text>

              <Text style={styles.postPreview}>{item.post}</Text>

              <Text style={styles.reasonTitle}>سبب البلاغ:</Text>
              <Text style={styles.cardText}>{item.reason}</Text>

              {item.status === "pending" && (
                <View style={styles.reportButtons}>
                  <TouchableOpacity
                    style={styles.removePost}
                    onPress={() => removePost(item.id)}
                  >
                    <Text style={styles.whiteText}>إزالة المنشور</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={styles.ignoreReport}
                    onPress={() => resolveReport(item.id)}
                  >
                    <Text style={styles.darkText}>تجاهل البلاغ</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          )}
        />
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  page: {
    flex: 1,
    backgroundColor: "#F8F5EF",
    padding: 22,
  },
  mapTop: {
    position: "absolute",
    top: 50,
    width: "92%",
    alignSelf: "center",
  },
  searchBox: {
    backgroundColor: "white",
    borderRadius: 25,
    paddingHorizontal: 15,
    height: 52,
    flexDirection: "row",
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  searchIcon: {
    fontSize: 18,
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
  },
  mapTabs: {
    flexDirection: "row-reverse",
    marginTop: 12,
    gap: 8,
    flexWrap: "wrap",
  },
  mapTab: {
    backgroundColor: "white",
    paddingVertical: 9,
    paddingHorizontal: 13,
    borderRadius: 20,
  },
  filterRow: {
    flexDirection: "row-reverse",
    gap: 8,
    marginTop: 10,
    flexWrap: "wrap",
  },
  filterBtn: {
    backgroundColor: "white",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 16,
  },
  activeSoftBtn: {
    backgroundColor: "#DDEDDD",
  },
  activeGreenTab: {
    backgroundColor: "#548D5D",
  },
  greenText: {
    color: "#548D5D",
    fontWeight: "700",
    textAlign: "center",
  },
  whiteText: {
    color: "white",
    fontWeight: "700",
    textAlign: "center",
  },
  darkText: {
    color: "#333",
    fontWeight: "800",
    textAlign: "center",
  },
  myLocationBtn: {
    position: "absolute",
    left: 18,
    top: 225,
    backgroundColor: "white",
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: "center",
    alignItems: "center",
  },
  adminFloat: {
    position: "absolute",
    right: 18,
    top: 230,
    backgroundColor: "#2F2F2F",
    padding: 12,
    borderRadius: 16,
  },
  reportFloat: {
    position: "absolute",
    right: 18,
    top: 285,
    backgroundColor: "#2F2F2F",
    padding: 12,
    borderRadius: 16,
  },
  placeSheet: {
    position: "absolute",
    bottom: 0,
    backgroundColor: "white",
    width: "100%",
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
    padding: 20,
  },
  sheetHandle: {
    width: 55,
    height: 5,
    backgroundColor: "#DDD",
    alignSelf: "center",
    borderRadius: 5,
    marginBottom: 12,
  },
  placeHeader: {
    flexDirection: "row-reverse",
    gap: 12,
    alignItems: "center",
  },
  placeLogo: {
    width: 70,
    height: 70,
    borderRadius: 14,
  },
  placeName: {
    fontSize: 22,
    fontWeight: "900",
    textAlign: "right",
  },
  placeType: {
    color: "#777",
    textAlign: "right",
  },
  placeInfo: {
    textAlign: "right",
    marginTop: 4,
  },
  openText: {
    color: "#228B45",
    fontWeight: "700",
    marginTop: 5,
    textAlign: "right",
  },
  statsRow: {
    flexDirection: "row-reverse",
    marginTop: 18,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: "#EEE",
    paddingVertical: 12,
  },
  statBox: {
    flex: 1,
    alignItems: "center",
  },
  statLabel: {
    color: "#777",
    fontSize: 12,
  },
  statValue: {
    color: "#548D5D",
    fontWeight: "800",
    marginTop: 4,
  },
  actionRow: {
    flexDirection: "row",
    gap: 12,
    marginTop: 16,
  },
  callBtn: {
    flex: 1,
    backgroundColor: "#EFF6EF",
    padding: 15,
    borderRadius: 16,
    alignItems: "center",
  },
  directionBtn: {
    flex: 1,
    backgroundColor: "#548D5D",
    padding: 15,
    borderRadius: 16,
    alignItems: "center",
  },
  back: {
    color: "#4384C4",
    fontSize: 18,
    marginBottom: 14,
  },
  detailImage: {
    height: 190,
    borderRadius: 22,
    marginBottom: 18,
  },
  bigTitle: {
    fontSize: 28,
    fontWeight: "900",
    textAlign: "right",
    marginBottom: 6,
    color: "#111",
  },
  typeText: {
    fontSize: 17,
    color: "#777",
    textAlign: "right",
    marginBottom: 10,
  },
  infoText: {
    fontSize: 16,
    textAlign: "right",
    marginTop: 8,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: "900",
    textAlign: "right",
    marginTop: 25,
    marginBottom: 8,
  },
  hoursBox: {
    backgroundColor: "white",
    padding: 14,
    borderRadius: 16,
  },
  normalText: {
    fontSize: 16,
    textAlign: "right",
    marginTop: 5,
  },
  greenButton: {
    backgroundColor: "#548D5D",
    padding: 16,
    borderRadius: 18,
    marginTop: 28,
  },
  blueButton: {
    backgroundColor: "#2798E8",
    padding: 16,
    borderRadius: 18,
    marginTop: 12,
    marginBottom: 40,
  },
  adminPage: {
    flex: 1,
    backgroundColor: "#F8F5EF",
    padding: 22,
  },
  adminHeader: {
    textAlign: "right",
    color: "#548D5D",
    fontWeight: "800",
    fontSize: 16,
  },
  subtitle: {
    color: "#777",
    textAlign: "right",
    marginBottom: 18,
    lineHeight: 22,
  },
  adminSearch: {
    backgroundColor: "white",
    borderRadius: 20,
    padding: 14,
    marginBottom: 14,
  },
  addPlaceBtn: {
    backgroundColor: "#548D5D",
    padding: 15,
    borderRadius: 16,
    marginBottom: 15,
    alignItems: "center",
  },
  adminTabs: {
    flexDirection: "row-reverse",
    gap: 8,
    marginBottom: 15,
  },
  adminTab: {
    flex: 1,
    backgroundColor: "white",
    padding: 12,
    borderRadius: 15,
    alignItems: "center",
  },
  adminActiveTab: {
    backgroundColor: "#548D5D",
  },
  countCard: {
    backgroundColor: "#2F7D46",
    borderRadius: 18,
    padding: 18,
    marginBottom: 16,
  },
  countLabel: {
    color: "white",
    textAlign: "right",
    fontSize: 16,
  },
  countNumberWhite: {
    color: "white",
    fontSize: 28,
    fontWeight: "900",
    textAlign: "center",
  },
  countNumber: {
    color: "#2F7D46",
    fontSize: 28,
    fontWeight: "900",
    textAlign: "center",
  },
  adminCard: {
    backgroundColor: "white",
    borderRadius: 20,
    padding: 14,
    marginBottom: 12,
    flexDirection: "row-reverse",
    gap: 12,
  },
  adminImage: {
    width: 90,
    height: 80,
    borderRadius: 14,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: "900",
    textAlign: "right",
  },
  cardText: {
    color: "#555",
    textAlign: "right",
    marginTop: 4,
  },
  badge: {
    alignSelf: "flex-end",
    backgroundColor: "#EAF4EA",
    color: "#548D5D",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    marginTop: 6,
    overflow: "hidden",
  },
  adminActions: {
    flexDirection: "row-reverse",
    alignItems: "center",
    gap: 8,
    marginTop: 10,
  },
  deleteSmall: {
    backgroundColor: "#FDECEC",
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 12,
  },
  deleteText: {
    color: "#E53935",
    fontWeight: "800",
  },
  editSmall: {
    backgroundColor: "#F1F1F1",
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 12,
  },
  loadMore: {
    borderWidth: 1,
    borderColor: "#DDD",
    borderStyle: "dashed",
    padding: 14,
    borderRadius: 16,
    alignItems: "center",
    marginBottom: 40,
  },
  formLabel: {
    fontWeight: "800",
    textAlign: "right",
    marginTop: 12,
    marginBottom: 6,
  },
  formInput: {
    backgroundColor: "white",
    padding: 14,
    borderRadius: 14,
  },
  imagePickerBtn: {
    backgroundColor: "#EAF4EA",
    padding: 14,
    borderRadius: 16,
    alignItems: "center",
    marginBottom: 12,
  },
  previewImage: {
    height: 150,
    borderRadius: 18,
    marginBottom: 10,
  },
  typeChoices: {
    flexDirection: "row-reverse",
    gap: 8,
    flexWrap: "wrap",
  },
  choiceBtn: {
    backgroundColor: "white",
    padding: 12,
    borderRadius: 14,
  },
  switchLine: {
    flexDirection: "row-reverse",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 15,
  },
  reportStats: {
    flexDirection: "row",
    gap: 12,
    marginBottom: 15,
  },
  reportStatBox: {
    flex: 1,
    backgroundColor: "white",
    borderRadius: 18,
    padding: 16,
    alignItems: "center",
  },
  reportCard: {
    backgroundColor: "white",
    borderRadius: 20,
    padding: 16,
    marginBottom: 14,
    borderRightWidth: 6,
    borderRightColor: "#548D5D",
  },
  reportTop: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  reportTag: {
    backgroundColor: "#FFE3D6",
    color: "#D66A2E",
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
    overflow: "hidden",
  },
  postPreview: {
    backgroundColor: "#F4F1EC",
    padding: 12,
    borderRadius: 12,
    marginTop: 12,
    textAlign: "right",
  },
  reasonTitle: {
    fontWeight: "900",
    textAlign: "right",
    marginTop: 12,
  },
  reportButtons: {
    flexDirection: "row",
    gap: 10,
    marginTop: 14,
  },
  removePost: {
    flex: 1,
    backgroundColor: "#E74B4B",
    padding: 13,
    borderRadius: 12,
  },
  ignoreReport: {
    flex: 1,
    backgroundColor: "#DDD",
    padding: 13,
    borderRadius: 12,
    alignItems: "center",
  },
  empty: {
    textAlign: "center",
    marginTop: 40,
    color: "#777",
  },
});