import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import { useAuth } from '../contexts/AuthContext';
import { usePets } from '../contexts/PetContext';
import { useReminders } from '../contexts/ReminderContext';
import { useBookmarks } from '../contexts/BookmarkContext';
import { useNavigation } from '@react-navigation/native';

export default function ProfileScreen() {
  const { user } = useAuth();
  const { pets } = usePets();
  const { reminders } = useReminders();
  const { bookmarks } = useBookmarks();
  const navigation = useNavigation();

  const stats = {
    petsCount: pets.length,
    bookmarksCount: bookmarks.length,
    activeReminders: reminders.length,
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>الملف الشخصي</Text>
        <TouchableOpacity
          onPress={() => alert('شاشة الإعدادات غير مطلوبة في المشروع')}
        >
          <Text style={styles.settings}>⚙️</Text>
        </TouchableOpacity>
      </View>

      {/* User Info */}
      <View style={styles.userInfo}>
        <Image
          source={
            user.avatar
              ? { uri: user.avatar }
              : { uri: 'https://via.placeholder.com/100' }
          }
          style={styles.avatar}
        />
        <Text style={styles.name}>{user.fullName}</Text>
        <Text style={styles.email}>{user.email}</Text>

        <TouchableOpacity
          style={styles.editBtn}
          onPress={() => navigation.navigate('EditProfile')}
        >
          <Text style={styles.editText}>تعديل الملف الشخصي</Text>
        </TouchableOpacity>
      </View>

      {/* Pets */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>حيواناتي الأليفة</Text>
          <TouchableOpacity
            onPress={() => navigation.navigate('AddEditPet', { mode: 'add' })}
          >
            <Text style={styles.addText}>+ إضافة</Text>
          </TouchableOpacity>
        </View>

        {pets.length === 0 ? (
          <Text style={styles.empty}>لا يوجد حيوانات</Text>
        ) : (
          <FlatList
            horizontal
            data={pets}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <TouchableOpacity
                style={styles.petCard}
                onPress={() =>
                  navigation.navigate('PetDetail', { petId: item.id })
                }
              >
                <Image
                  source={
                    item.photo
                      ? { uri: item.photo }
                      : { uri: 'https://via.placeholder.com/80' }
                  }
                  style={styles.petImage}
                />
                <Text style={styles.petName}>{item.name}</Text>
              </TouchableOpacity>
            )}
          />
        )}
      </View>

      {/* Stats */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>الإحصائيات</Text>
        <View style={styles.statsRow}>
          <View style={styles.statBox}>
            <Text style={styles.statNum}>{stats.petsCount}</Text>
            <Text style={styles.statLabel}>حيوانات</Text>
          </View>
          <View style={styles.statBox}>
            <Text style={styles.statNum}>{stats.bookmarksCount}</Text>
            <Text style={styles.statLabel}>مقالات محفوظة</Text>
          </View>
          <View style={styles.statBox}>
            <Text style={styles.statNum}>{stats.activeReminders}</Text>
            <Text style={styles.statLabel}>تذكيرات</Text>
          </View>
        </View>
      </View>

      {/* Menu */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>القائمة</Text>

        <TouchableOpacity style={styles.menuItem}>
          <Text style={styles.menuText}>المحفوظات</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => navigation.navigate('RemindersTab')}
        >
          <Text style={styles.menuText}>التذكيرات</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.menuItem}>
          <Text style={styles.menuText}>عن التطبيق</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#F7F7F7' },
  header: { flexDirection: 'row', justifyContent: 'space-between' },
  headerTitle: { fontSize: 20, fontWeight: 'bold' },
  settings: { fontSize: 22 },
  userInfo: { alignItems: 'center', marginVertical: 16 },
  avatar: { width: 90, height: 90, borderRadius: 45, backgroundColor: '#DDD' },
  name: { fontSize: 18, fontWeight: 'bold', marginTop: 8 },
  email: { fontSize: 14, color: '#666' },
  editBtn: {
    marginTop: 10,
    backgroundColor: '#4CAF50',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 20,
  },
  editText: { color: '#FFF', fontWeight: 'bold' },
  section: { marginTop: 20 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between' },
  sectionTitle: { fontSize: 16, fontWeight: 'bold' },
  addText: { color: '#4CAF50', fontWeight: 'bold' },
  empty: { color: '#777', marginTop: 10 },
  petCard: {
    width: 100,
    backgroundColor: '#FFF',
    padding: 8,
    borderRadius: 12,
    marginRight: 10,
    alignItems: 'center',
  },
  petImage: { width: 60, height: 60, borderRadius: 30 },
  petName: { marginTop: 6 },
  statsRow: { flexDirection: 'row', justifyContent: 'space-between' },
  statBox: {
    backgroundColor: '#FFF',
    padding: 12,
    borderRadius: 12,
    width: '30%',
    alignItems: 'center',
  },
  statNum: { fontSize: 18, fontWeight: 'bold' },
  statLabel: { fontSize: 12, color: '#666' },
  menuItem: {
    backgroundColor: '#FFF',
    padding: 12,
    borderRadius: 10,
    marginTop: 10,
  },
  menuText: { fontSize: 14 },
});
