import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  TouchableOpacity,
  Alert,
  ScrollView,
} from 'react-native';
import { useRoute, useNavigation } from '@react-navigation/native';
import { usePets } from '../contexts/PetContext';
import { useReminders } from '../contexts/ReminderContext';

export default function PetDetailScreen() {
  const route = useRoute();
  const navigation = useNavigation();
  const { petId } = route.params;

  const { getPetById, deletePet } = usePets();
  const { reminders, deleteReminder } = useReminders();

  const pet = getPetById(petId);

  const petReminders = reminders.filter((r) => r.petId === petId);

  const remove = () => {
    Alert.alert('تأكيد', 'هل تريد حذف هذا الأليف؟', [
      { text: 'إلغاء' },
      {
        text: 'حذف',
        style: 'destructive',
        onPress: async () => {
          for (const r of petReminders) {
            await deleteReminder(r.id);
          }
          await deletePet(petId);
          navigation.goBack();
        },
      },
    ]);
  };

  return (
    <ScrollView style={styles.container}>
      <Image
        source={
          pet.photo
            ? { uri: pet.photo }
            : { uri: 'https://via.placeholder.com/200' }
        }
        style={styles.image}
      />

      <View style={styles.box}>
        <Text style={styles.name}>{pet.name}</Text>

        <Text style={styles.label}>النوع: <Text style={styles.value}>{pet.type}</Text></Text>
        <Text style={styles.label}>السلالة: <Text style={styles.value}>{pet.breed}</Text></Text>
        <Text style={styles.label}>تاريخ الميلاد: <Text style={styles.value}>{pet.birthDate}</Text></Text>
        <Text style={styles.label}>الجنس: <Text style={styles.value}>{pet.gender}</Text></Text>
        <Text style={styles.label}>الوزن: <Text style={styles.value}>{pet.weight} kg</Text></Text>
        <Text style={styles.label}>اللون: <Text style={styles.value}>{pet.color}</Text></Text>

        <Text style={styles.label}>ملاحظات:</Text>
        <Text style={styles.notes}>{pet.notes || 'لا يوجد'}</Text>

        <View style={styles.row}>
          <TouchableOpacity
            style={[styles.btn, styles.edit]}
            onPress={() =>
              navigation.navigate('AddEditPet', { mode: 'edit', petId })
            }
          >
            <Text style={styles.btnText}>تعديل</Text>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.btn, styles.delete]} onPress={remove}>
            <Text style={styles.btnText}>حذف</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor: '#F7F7F7' },
  image: { width: '100%', height: 220 },
  box: { padding: 16 },
  name: { fontSize: 22, fontWeight: 'bold', marginBottom: 10 },
  label: { marginTop: 6, fontSize: 14 },
  value: { fontWeight: 'bold' },
  notes: {
    backgroundColor: '#FFF',
    padding: 10,
    borderRadius: 8,
    marginTop: 4,
  },
  row: { flexDirection: 'row', marginTop: 20 },
  btn: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginHorizontal: 4,
  },
  edit: { backgroundColor: '#2196F3' },
  delete: { backgroundColor: '#F44336' },
  btnText: { color: '#FFF', fontWeight: 'bold' },
});
