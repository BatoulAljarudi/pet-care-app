import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  Alert,
  ScrollView,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import { useRoute, useNavigation } from '@react-navigation/native';
import { usePets } from '../contexts/PetContext';

const TYPES = ['قطط', 'كلاب', 'طيور', 'صقور', 'أخرى'];

export default function AddEditPetScreen() {
  const route = useRoute();
  const navigation = useNavigation();
  const { mode, petId } = route.params || { mode: 'add' };

  const { addPet, updatePet, getPetById } = usePets();

  const editing = mode === 'edit';
  const existing = editing ? getPetById(petId) : null;

  const [photo, setPhoto] = useState(existing?.photo || null);
  const [name, setName] = useState(existing?.name || '');
  const [type, setType] = useState(existing?.type || '');
  const [breed, setBreed] = useState(existing?.breed || '');
  const [birthDate, setBirthDate] = useState(
    existing?.birthDate ? new Date(existing.birthDate) : new Date()
  );
  const [showDate, setShowDate] = useState(false);
  const [gender, setGender] = useState(existing?.gender || '');
  const [weight, setWeight] = useState(existing?.weight || '');
  const [color, setColor] = useState(existing?.color || '');
  const [notes, setNotes] = useState(existing?.notes || '');

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.7,
    });

    if (!result.canceled) {
      setPhoto(result.assets[0].uri);
    }
  };

  const save = async () => {
    if (!name.trim()) return Alert.alert('خطأ', 'اسم الحيوان مطلوب');
    if (!type) return Alert.alert('خطأ', 'نوع الحيوان مطلوب');
    if (!photo) return Alert.alert('خطأ', 'الصورة مطلوبة');

    const data = {
      photo,
      name,
      type,
      breed,
      birthDate: birthDate.toISOString().split('T')[0],
      gender,
      weight,
      color,
      notes,
    };

    if (editing) {
      await updatePet(petId, data);
    } else {
      await addPet(data);
    }

    navigation.goBack();
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.center}>
        <Image
          source={
            photo
              ? { uri: photo }
              : { uri: 'https://via.placeholder.com/120' }
          }
          style={styles.photo}
        />
        <TouchableOpacity style={styles.photoBtn} onPress={pickImage}>
          <Text style={styles.photoText}>
            {photo ? 'Change Photo' : 'Add Photo'}
          </Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.label}>اسم الحيوان</Text>
      <TextInput
        style={styles.input}
        value={name}
        onChangeText={setName}
        placeholder="مثلاً: لوسي"
      />

      <Text style={styles.label}>نوع الحيوان</Text>
      <View style={styles.rowWrap}>
        {TYPES.map((t) => (
          <TouchableOpacity
            key={t}
            style={[styles.chip, type === t && styles.chipSelected]}
            onPress={() => setType(t)}
          >
            <Text
              style={[styles.chipText, type === t && styles.chipTextSelected]}
            >
              {t}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>السلالة</Text>
      <TextInput
        style={styles.input}
        value={breed}
        onChangeText={setBreed}
        placeholder="مثلاً: شيرازي"
      />

      <Text style={styles.label}>تاريخ الميلاد</Text>
      <TouchableOpacity style={styles.input} onPress={() => setShowDate(true)}>
        <Text>{birthDate.toISOString().split('T')[0]}</Text>
      </TouchableOpacity>

      {showDate && (
        <DateTimePicker
          value={birthDate}
          mode="date"
          onChange={(e, d) => {
            setShowDate(false);
            if (d) setBirthDate(d);
          }}
        />
      )}

      <Text style={styles.label}>الجنس</Text>
      <View style={styles.row}>
        {['ذكر', 'أنثى'].map((g) => (
          <TouchableOpacity
            key={g}
            style={[styles.chip, gender === g && styles.chipSelected]}
            onPress={() => setGender(g)}
          >
            <Text
              style={[styles.chipText, gender === g && styles.chipTextSelected]}
            >
              {g}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>الوزن (kg)</Text>
      <TextInput
        style={styles.input}
        value={weight}
        onChangeText={setWeight}
        keyboardType="numeric"
      />

      <Text style={styles.label}>اللون</Text>
      <TextInput
        style={styles.input}
        value={color}
        onChangeText={setColor}
      />

      <Text style={styles.label}>ملاحظات</Text>
      <TextInput
        style={[styles.input, { height: 80 }]}
        value={notes}
        onChangeText={setNotes}
        multiline
      />

      <TouchableOpacity style={styles.saveBtn} onPress={save}>
        <Text style={styles.saveText}>حفظ</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16, backgroundColor: '#F7F7F7' },
  center: { alignItems: 'center', marginBottom: 20 },
  photo: { width: 120, height: 120, borderRadius: 60, backgroundColor: '#DDD' },
  photoBtn: {
    marginTop: 10,
    borderWidth: 1,
    borderColor: '#4CAF50',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  photoText: { color: '#4CAF50' },
  label: { marginTop: 10, marginBottom: 4 },
  input: {
    backgroundColor: '#FFF',
    padding: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#DDD',
  },
  rowWrap: { flexDirection: 'row', flexWrap: 'wrap' },
  row: { flexDirection: 'row' },
  chip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#CCC',
    marginRight: 8,
    marginBottom: 8,
  },
  chipSelected: { backgroundColor: '#4CAF50', borderColor: '#4CAF50' },
  chipText: { fontSize: 12 },
  chipTextSelected: { color: '#FFF' },
  saveBtn: {
    marginTop: 20,
    backgroundColor: '#4CAF50',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  saveText: { color: '#FFF', fontWeight: 'bold' },
});
