import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Image,
  Alert,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { useAuth } from '../contexts/AuthContext';
import { useNavigation } from '@react-navigation/native';

export default function EditProfileScreen() {
  const { user, updateUser } = useAuth();
  const navigation = useNavigation();

  const [fullName, setFullName] = useState(user.fullName);
  const [email, setEmail] = useState(user.email);
  const [phone, setPhone] = useState(user.phone);
  const [avatar, setAvatar] = useState(user.avatar);

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.7,
    });

    if (!result.canceled) {
      setAvatar(result.assets[0].uri);
    }
  };

  const save = async () => {
    if (!fullName.trim()) return Alert.alert('خطأ', 'الاسم مطلوب');
    if (!email.includes('@')) return Alert.alert('خطأ', 'البريد غير صحيح');

    await updateUser({ fullName, email, phone, avatar });
    Alert.alert('تم', 'تم حفظ التغييرات', [
      { text: 'رجوع', onPress: () => navigation.goBack() },
    ]);
  };

  return (
    <View style={styles.container}>
      <View style={styles.center}>
        <Image
          source={
            avatar
              ? { uri: avatar }
              : { uri: 'https://via.placeholder.com/100' }
          }
          style={styles.avatar}
        />
        <TouchableOpacity style={styles.photoBtn} onPress={pickImage}>
          <Text style={styles.photoText}>Change Photo</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.label}>الاسم الكامل</Text>
      <TextInput
        style={styles.input}
        value={fullName}
        onChangeText={setFullName}
      />

      <Text style={styles.label}>البريد الإلكتروني</Text>
      <TextInput
        style={styles.input}
        value={email}
        onChangeText={setEmail}
      />

      <Text style={styles.label}>رقم الجوال</Text>
      <TextInput
        style={styles.input}
        value={phone}
        onChangeText={setPhone}
      />

      <TouchableOpacity style={styles.saveBtn} onPress={save}>
        <Text style={styles.saveText}>حفظ التغييرات</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16, backgroundColor: '#F7F7F7', flex: 1 },
  center: { alignItems: 'center', marginBottom: 20 },
  avatar: { width: 100, height: 100, borderRadius: 50, backgroundColor: '#DDD' },
  photoBtn: {
    marginTop: 10,
    borderWidth: 1,
    borderColor: '#4CAF50',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  photoText: { color: '#4CAF50' },
  label: { marginTop: 10, marginBottom: 4 },
  input: {
    backgroundColor: '#FFF',
    padding: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#DDD',
  },
  saveBtn: {
    marginTop: 20,
    backgroundColor: '#4CAF50',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  saveText: { color: '#FFF', fontWeight: 'bold' },
});
