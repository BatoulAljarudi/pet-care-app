 import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  FlatList,
  Alert,
} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { useRoute, useNavigation } from '@react-navigation/native';
import { usePets } from '../contexts/PetContext';
import { useReminders } from '../contexts/ReminderContext';

const TYPES = ['تطعيم', 'إطعام', 'دواء', 'فحص', 'أخرى'];

export default function AddEditReminderScreen() {
  const route = useRoute();
  const navigation = useNavigation();

  const { pets } = usePets();
  const { reminders, addReminder, updateReminder } = useReminders();

  const { mode, reminderId } = route.params || { mode: 'add' };

  const editing = mode === 'edit';
  const existing = editing ? reminders.find((r) => r.id === reminderId) : null;

  const [petId, setPetId] = useState(existing?.petId || null);
  const [type, setType] = useState(existing?.type || '');
  const [title, setTitle] = useState(existing?.title || '');
  const [dateTime, setDateTime] = useState(
    existing ? new Date(existing.dateTime) : new Date()
  );
  const [showDate, setShowDate] = useState(false);
  const [showTime, setShowTime] = useState(false);
  const [notes, setNotes] = useState(existing?.notes || '');

  const save = async () => {
    if (!petId) return Alert.alert('خطأ', 'اختر الأليف');
    if (!type) return Alert.alert('خطأ', 'اختر نوع التذكير');
    if (!title.trim()) return Alert.alert('خطأ', 'العنوان مطلوب');

    const data = {
      petId,
      type,
      title,
      dateTime: dateTime.toISOString(),
      notes,
      active: true,
    };

    if (editing) {
      await updateReminder(reminderId, data);
    } else {
      await addReminder(data);
    }

    navigation.goBack();
  };

  const renderPet = ({ item }) => (
    <TouchableOpacity
      style={[styles.petCard, petId === item.id && styles.petSelected]}
      onPress={() => setPetId(item.id)}
    >
      <Text style={styles.petText}>{item.name}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.sectionTitle}>اختر الأليف</Text>

      <FlatList
        horizontal
        data={pets}
        keyExtractor={(i) => i.id}
        renderItem={renderPet}
        style={{ marginBottom: 10 }}
      />

      <Text style={styles.sectionTitle}>نوع التذكير</Text>
      <View style={styles.rowWrap}>
        {TYPES.map((t) => (
          <TouchableOpacity
            key={t}
            style={[styles.chip, type === t && styles.chipSelected]}
            onPress={() => setType(t)}
          >
            <Text
              style={[styles.chipText, type === t && styles.chipTextSelected]}
            >
              {t}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <Text style={styles.label}>العنوان</Text>
      <TextInput
        style={styles.input}
        value={title}
        onChangeText={setTitle}
        placeholder="مثلاً: موعد العيادة"
      />

      <Text style={styles.label}>التاريخ</Text>
      <TouchableOpacity style={styles.input} onPress={() => setShowDate(true)}>
        <Text>{dateTime.toISOString().split('T')[0]}</Text>
      </TouchableOpacity>

      {showDate && (
        <DateTimePicker
          value={dateTime}
          mode="date"
          onChange={(e, d) => {
            setShowDate(false);
            if (d) {
              const newDate = new Date(dateTime);
              newDate.setFullYear(d.getFullYear(), d.getMonth(), d.getDate());
              setDateTime(newDate);
            }
          }}
        />
      )}

      <Text style={styles.label}>الوقت</Text>
      <TouchableOpacity style={styles.input} onPress={() => setShowTime(true)}>
        <Text>{dateTime.toLocaleTimeString('ar-SA')}</Text>
      </TouchableOpacity>

      {showTime && (
        <DateTimePicker
          value={dateTime}
          mode="time"
          onChange={(e, t) => {
            setShowTime(false);
            if (t) {
              const newDate = new Date(dateTime);
              newDate.setHours(t.getHours(), t.getMinutes());
              setDateTime(newDate);
            }
          }}
        />
      )}

      <Text style={styles.label}>ملاحظات</Text>
      <TextInput
        style={[styles.input, { height: 80 }]}
        value={notes}
        onChangeText={setNotes}
        multiline
      />

      <TouchableOpacity style={styles.saveBtn} onPress={save}>
        <Text style={styles.saveText}>حفظ التذكير</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16, backgroundColor: '#F7F7F7', flex: 1 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', marginBottom: 6 },
  rowWrap: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 10 },
  chip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#CCC',
    marginRight: 8,
    marginBottom: 8,
  },
  chipSelected: { backgroundColor: '#4CAF50', borderColor: '#4CAF50' },
  chipText: { fontSize: 12 },
  chipTextSelected: { color: '#FFF' },
  label: { marginTop: 10, marginBottom: 4 },
  input: {
    backgroundColor: '#FFF',
    padding: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#DDD',
    marginBottom: 10,
  },
  petCard: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 16,
    backgroundColor: '#FFF',
    borderWidth: 1,
    borderColor: '#CCC',
    marginRight: 8,
  },
  petSelected: { backgroundColor: '#4CAF50', borderColor: '#4CAF50' },
  petText: { fontSize: 13 },
  saveBtn: {
    marginTop: 20,
    backgroundColor: '#4CAF50',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  saveText: { color: '#FFF', fontWeight: 'bold' },
});
