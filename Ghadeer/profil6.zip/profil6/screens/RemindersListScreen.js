import React, { useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Switch,
  Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useReminders } from '../contexts/ReminderContext';
import { usePets } from '../contexts/PetContext';

export default function RemindersListScreen() {
  const navigation = useNavigation();
  const { reminders, deleteReminder, updateReminder } = useReminders();
  const { pets } = usePets();

  const getPetName = (id) =>
    pets.find((p) => p.id === id)?.name || 'أليف';

  const today = new Date();

  const groups = useMemo(() => {
    const todayList = [];
    const upcoming = [];
    const past = [];

    reminders.forEach((r) => {
      const d = new Date(r.dateTime);

      if (d.toDateString() === today.toDateString()) todayList.push(r);
      else if (d > today) upcoming.push(r);
      else past.push(r);
    });

    return { todayList, upcoming, past };
  }, [reminders]);

  const renderItem = (item) => (
    <View style={styles.card}>
      <View style={{ flex: 1 }}>
        <Text style={styles.title}>{item.title}</Text>
        <Text style={styles.sub}>
          {item.type} • {getPetName(item.petId)}
        </Text>
        <Text style={styles.sub}>
          {new Date(item.dateTime).toLocaleString('ar-SA')}
        </Text>
      </View>

      <View style={styles.actions}>
        <Switch
          value={item.active}
          onValueChange={() =>
            updateReminder(item.id, { active: !item.active })
          }
        />

        <TouchableOpacity
          onPress={() =>
            navigation.navigate('AddEditReminder', {
              mode: 'edit',
              reminderId: item.id,
            })
          }
        >
          <Text style={styles.icon}>✏️</Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() =>
            Alert.alert('تأكيد', 'حذف التذكير؟', [
              { text: 'إلغاء' },
              {
                text: 'حذف',
                style: 'destructive',
                onPress: () => deleteReminder(item.id),
              },
            ])
          }
        >
          <Text style={styles.icon}>🗑️</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  const renderSection = (title, data) => (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>

      {data.length === 0 ? (
        <Text style={styles.empty}>لا يوجد تذكيرات</Text>
      ) : (
        <FlatList
          data={data}
          keyExtractor={(i) => i.id}
          renderItem={({ item }) => renderItem(item)}
        />
      )}
    </View>
  );

  return (
    <View style={styles.container}>
      {renderSection('اليوم', groups.todayList)}
      {renderSection('القادمة', groups.upcoming)}
      {renderSection('السابقة', groups.past)}

      <TouchableOpacity
        style={styles.fab}
        onPress={() => navigation.navigate('AddEditReminder', { mode: 'add' })}
      >
        <Text style={styles.fabText}>+</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16, backgroundColor: '#F7F7F7', flex: 1 },
  section: { marginBottom: 20 },
  sectionTitle: { fontSize: 16, fontWeight: 'bold', marginBottom: 8 },
  empty: { color: '#777' },
  card: {
    backgroundColor: '#FFF',
    padding: 12,
    borderRadius: 10,
    marginBottom: 10,
    flexDirection: 'row',
  },
  title: { fontSize: 15, fontWeight: 'bold' },
  sub: { fontSize: 12, color: '#666' },
  actions: { alignItems: 'center', justifyContent: 'space-between' },
  icon: { fontSize: 20, marginTop: 10 },
  fab: {
    position: 'absolute',
    bottom: 25,
    right: 25,
    backgroundColor: '#4CAF50',
    width: 55,
    height: 55,
    borderRadius: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  fabText: { color: '#FFF', fontSize: 30 },
});
