 import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import { AuthProvider } from './contexts/AuthContext';
import { PetProvider } from './contexts/PetContext';
import { ReminderProvider } from './contexts/ReminderContext';
import { BookmarkProvider } from './contexts/BookmarkContext';

import ProfileScreen from './screens/ProfileScreen';
import EditProfileScreen from './screens/EditProfileScreen';
import PetDetailScreen from './screens/PetDetailScreen';
import AddEditPetScreen from './screens/AddEditPetScreen';
import RemindersListScreen from './screens/RemindersListScreen';
import AddEditReminderScreen from './screens/AddEditReminderScreen';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function MainTabs() {
  return (
    <Tab.Navigator screenOptions={{ headerShown: false }}>
      <Tab.Screen
        name="ProfileTab"
        component={ProfileScreen}
        options={{ title: 'الملف الشخصي' }}
      />
      <Tab.Screen
        name="RemindersTab"
        component={RemindersListScreen}
        options={{ title: 'التذكيرات' }}
      />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BookmarkProvider>
        <PetProvider>
          <ReminderProvider>
            <NavigationContainer>
              <StatusBar style="dark" />
              <Stack.Navigator>
                <Stack.Screen
                  name="MainTabs"
                  component={MainTabs}
                  options={{ headerShown: false }}
                />

                <Stack.Screen
                  name="EditProfile"
                  component={EditProfileScreen}
                  options={{ title: 'تعديل الملف الشخصي' }}
                />

                <Stack.Screen
                  name="PetDetail"
                  component={PetDetailScreen}
                  options={{ title: 'تفاصيل الأليف' }}
                />

                <Stack.Screen
                  name="AddEditPet"
                  component={AddEditPetScreen}
                  options={{ title: 'إضافة / تعديل أليف' }}
                />

                <Stack.Screen
                  name="AddEditReminder"
                  component={AddEditReminderScreen}
                  options={{ title: 'إضافة / تعديل تذكير' }}
                />
              </Stack.Navigator>
            </NavigationContainer>
          </ReminderProvider>
        </PetProvider>
      </BookmarkProvider>
    </AuthProvider>
  );
}
