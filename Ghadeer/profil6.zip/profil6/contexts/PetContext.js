import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

function generateId() {
  return Math.random().toString(36).substring(2, 10);
}

const PetContext = createContext();

export function PetProvider({ children }) {
  const [pets, setPets] = useState([]);

  useEffect(() => {
    const load = async () => {
      const stored = await AsyncStorage.getItem('pets');
      if (stored) setPets(JSON.parse(stored));
    };
    load();
  }, []);

  const save = async (newPets) => {
    setPets(newPets);
    await AsyncStorage.setItem('pets', JSON.stringify(newPets));
  };

  const addPet = async (pet) => {
    const newPet = { ...pet, id: generateId() };
    await save([...pets, newPet]);
  };

  const updatePet = async (id, updated) => {
    const newPets = pets.map((p) => (p.id === id ? { ...p, ...updated } : p));
    await save(newPets);
  };

  const deletePet = async (id) => {
    const newPets = pets.filter((p) => p.id !== id);
    await save(newPets);
  };

  const getPetById = (id) => pets.find((p) => p.id === id);

  return (
    <PetContext.Provider value={{ pets, addPet, updatePet, deletePet, getPetById }}>
      {children}
    </PetContext.Provider>
  );
}

export function usePets() {
  return useContext(PetContext);
}
