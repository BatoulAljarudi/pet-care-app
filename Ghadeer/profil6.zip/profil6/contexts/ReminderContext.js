import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';

function generateId() {
  return Math.random().toString(36).substring(2, 10);
}

const ReminderContext = createContext();

export function ReminderProvider({ children }) {
  const [reminders, setReminders] = useState([]);

  useEffect(() => {
    const load = async () => {
      const stored = await AsyncStorage.getItem('reminders');
      if (stored) setReminders(JSON.parse(stored));
    };
    load();
  }, []);

  const save = async (newList) => {
    setReminders(newList);
    await AsyncStorage.setItem('reminders', JSON.stringify(newList));
  };

  const addReminder = async (reminder) => {
    const id = generateId();
    const newReminder = { ...reminder, id };
    await save([...reminders, newReminder]);
  };

  const updateReminder = async (id, updated) => {
    const newList = reminders.map((r) => (r.id === id ? { ...r, ...updated } : r));
    await save(newList);
  };

  const deleteReminder = async (id) => {
    const newList = reminders.filter((r) => r.id !== id);
    await save(newList);
  };

  return (
    <ReminderContext.Provider
      value={{ reminders, addReminder, updateReminder, deleteReminder }}
    >
      {children}
    </ReminderContext.Provider>
  );
}

export function useReminders() {
  return useContext(ReminderContext);
}
